import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { Circle, Marker, Polyline, useJsApiLoader } from "@react-google-maps/api";
import {
  ArrowLeft,
  Bike,
  Box,
  Car,
  ChevronRight,
  Clock,
  CreditCard,
  Crosshair,
  LogOut,
  MapPin,
  Moon,
  Navigation2,
  Package,
  Phone,
  Search,
  Send,
  Shield,
  Star,
  Sun,
  Sunrise,
  Sunset,
  Truck,
  X,
  Zap,
  type LucideIcon,
} from "lucide-react";
import { MovviMap } from "@/components/MovviMap";
import { MovviSheet, type MovviSheetHandle } from "@/components/MovviSheet";
import { supabase } from "@/integrations/supabase/client";
import {
  BRAZIL_CENTER,
  GOOGLE_MAPS_API_KEY,
  GOOGLE_MAPS_LIBRARIES,
  isBrazilCoordinate,
  purgeForeignMapCache,
} from "@/lib/googleMaps";
import { DEV_MODE, isDevelopmentEnvironment } from "@/lib/environment";

import { computeRoute, type RouteResult } from "@/lib/routes.functions";
import { reverseGeocode, type GeocodeResult } from "@/lib/geocode.functions";
import { criarCorrida, cancelarPeloPassageiro } from "@/lib/rideLifecycle";
import { useNearbyDrivers } from "@/hooks/useNearbyDrivers";
import {
  RIDE_CATEGORIES,
  estimateFare,
  formatBRL,
  type RideCategory,
  type TariffMap,
} from "@/lib/rideCategories";
import { loadTariffs } from "@/lib/tariffs";

import type { Database } from "@/integrations/supabase/types";

/** Saudação dinâmica com base no horário local (pt-BR). */
function getGreeting(): { text: string; icon: LucideIcon } {
  const h = new Date().getHours();
  if (h >= 5 && h < 12) return { text: "Bom dia", icon: Sunrise };
  if (h >= 12 && h < 18) return { text: "Boa tarde", icon: Sun };
  if (h >= 18 && h < 22) return { text: "Boa noite", icon: Sunset };
  return { text: "Boa noite", icon: Moon };
}

function firstName(full: string): string {
  return (full || "").trim().split(/\s+/)[0] || "";
}

// ====== COMPONENTES PREMIUM ======

function PremiumTopBar({
  userName,
  gpsState,
  drivers,
  searching,
  onLogout,
}: {
  userName: string;
  gpsState: "idle" | "requesting" | "granted" | "denied" | "unavailable";
  drivers: number;
  searching: boolean;
  onLogout: () => void;
}) {
  const { text: greet, icon: GIcon } = getGreeting();
  const fname = firstName(userName) || "passageiro";

  let statusIcon = "🔎";
  let statusText = "Procurando motoristas próximos";
  if (gpsState === "requesting" || gpsState === "idle") {
    statusIcon = "📍";
    statusText = "Obtendo sua localização...";
  } else if (gpsState === "unavailable" || gpsState === "denied") {
    statusIcon = "⚠️";
    statusText = "Localização indisponível";
  } else if (searching) {
    statusIcon = "🔎";
    statusText = "Procurando motoristas próximos";
  } else if (drivers > 0) {
    statusIcon = "🚗";
    statusText = `${drivers} ${drivers === 1 ? "motorista próximo" : "motoristas próximos"}`;
  }

  return (
    <div className="absolute inset-x-0 top-0 z-40 px-3 pt-[calc(env(safe-area-inset-top)+10px)]">
      <div className="mx-auto flex max-w-5xl items-center gap-3 rounded-2xl bg-card/90 px-3 py-2.5 shadow-xl ring-1 ring-border/60 backdrop-blur-xl animate-in fade-in slide-in-from-top-2 duration-500">
        <div className="grid h-10 w-10 shrink-0 place-items-center rounded-full bg-primary/15 text-primary ring-1 ring-primary/30">
          <GIcon className="h-5 w-5" />
        </div>
        <div className="min-w-0 flex-1">
          <div className="truncate text-[14px] font-semibold leading-tight text-foreground">
            {greet}, {fname} <span className="opacity-90">👋</span>
          </div>
          <div className="mt-0.5 flex items-center gap-1.5 truncate text-[11px] text-muted-foreground">
            <span className="text-[12px] leading-none">{statusIcon}</span>
            <span className="truncate">{statusText}</span>
          </div>
        </div>
        <button
          onClick={onLogout}
          aria-label="Sair"
          className="inline-flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-destructive/15 text-destructive ring-1 ring-destructive/30 transition hover:bg-destructive/25 active:scale-90"
        >
          <LogOut className="h-4 w-4" />
        </button>
      </div>
    </div>
  );
}

function PulsingUserMarker({ position }: { position: LatLng }) {
  const pulseIcon = useMemo(
    () => ({
      path: google.maps.SymbolPath.CIRCLE,
      scale: 22,
      fillColor: "#3b82f6",
      fillOpacity: 0.18,
      strokeColor: "#3b82f6",
      strokeOpacity: 0.35,
      strokeWeight: 1,
    }),
    [],
  );
  const dotIcon = useMemo(
    () => ({
      path: google.maps.SymbolPath.CIRCLE,
      scale: 8,
      fillColor: "#3b82f6",
      fillOpacity: 1,
      strokeColor: "#ffffff",
      strokeWeight: 3,
    }),
    [],
  );
  return (
    <>
      <Marker position={position} icon={pulseIcon} clickable={false} zIndex={9998} />
      <Marker position={position} icon={dotIcon} zIndex={9999} />
    </>
  );
}

function OriginActionsSheet({
  geo,
  position,
  onClose,
  onUseGps,
  onPickOnMap,
  onTypeAddress,
  gpsRequesting,
}: {
  geo: GeocodeResult | null;
  position: LatLng | null;
  onClose: () => void;
  onUseGps: () => void;
  onPickOnMap: () => void;
  onTypeAddress: () => void;
  gpsRequesting: boolean;
}) {
  const isExact = geo?.precision === "exact";
  const rua = geo?.components.rua;
  const numero = geo?.components.numero;
  const bairro = geo?.components.bairro || geo?.components.povoado;
  const region = geo?.region;
  const ruaLine = isExact && rua ? (numero ? `${rua}, ${numero}` : rua) : "";

  return (
    <div className="fixed inset-0 z-[60] flex items-end" onClick={onClose}>
      <div className="absolute inset-0 bg-black/60 backdrop-blur-sm animate-in fade-in duration-200" />
      <div
        onClick={(e) => e.stopPropagation()}
        className="relative w-full rounded-t-3xl bg-card p-5 pb-[calc(env(safe-area-inset-bottom)+20px)] shadow-2xl ring-1 ring-border animate-in slide-in-from-bottom duration-300"
      >
        <div className="mx-auto mb-3 h-1.5 w-12 rounded-full bg-foreground/15" />
        <div className="mb-4 flex items-start gap-3">
          <span className="grid h-10 w-10 shrink-0 place-items-center rounded-full bg-primary text-primary-foreground">
            <MapPin className="h-4 w-4" />
          </span>
          <div className="min-w-0 flex-1">
            <div className="text-[10px] font-semibold uppercase tracking-widest text-primary">
              Local de partida
            </div>
            {ruaLine ? (
              <>
                <div className="mt-0.5 truncate text-[15px] font-bold text-foreground">{ruaLine}</div>
                {bairro && <div className="truncate text-[12.5px] text-foreground/80">{bairro}</div>}
                {region && <div className="truncate text-[12px] text-muted-foreground">{region}</div>}
              </>
            ) : position ? (
              <>
                <div className="mt-0.5 text-[13px] font-semibold text-amber-400">
                  Localização aproximada
                </div>
                <div className="mt-0.5 font-mono text-[12px] text-foreground">
                  Lat: {position.lat.toFixed(6)} • Lng: {position.lng.toFixed(6)}
                </div>
                {region && (
                  <div className="truncate text-[12px] text-muted-foreground">
                    Referência: {region}
                  </div>
                )}
              </>
            ) : (
              <div className="mt-0.5 text-[13px] text-muted-foreground">Sem endereço identificado</div>
            )}
          </div>
        </div>

        <div className="space-y-2">
          <OriginAction
            icon={<Crosshair className="h-4 w-4" />}
            label="Usar minha localização novamente"
            description="Recapturar GPS do aparelho"
            onClick={onUseGps}
            disabled={gpsRequesting}
            primary
          />
          <OriginAction
            icon={<Navigation2 className="h-4 w-4" />}
            label="Escolher outro local no mapa"
            description="Arraste o mapa e confirme o ponto"
            onClick={onPickOnMap}
          />
          <OriginAction
            icon={<Search className="h-4 w-4" />}
            label="Digitar outro endereço"
            description="Buscar pelo nome da rua, bairro ou CEP"
            onClick={onTypeAddress}
          />
          <button
            type="button"
            onClick={onClose}
            className="w-full rounded-2xl bg-background/60 py-3 text-sm font-semibold text-muted-foreground ring-1 ring-border transition active:scale-[0.98]"
          >
            Cancelar
          </button>
        </div>
      </div>
    </div>
  );
}

function OriginAction({
  icon,
  label,
  description,
  onClick,
  disabled,
  primary,
}: {
  icon: React.ReactNode;
  label: string;
  description: string;
  onClick: () => void;
  disabled?: boolean;
  primary?: boolean;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      disabled={disabled}
      className={`flex w-full items-center gap-3 rounded-2xl px-3 py-3 text-left transition active:scale-[0.98] disabled:opacity-60 ${
        primary
          ? "bg-primary/15 ring-1 ring-primary/40 hover:bg-primary/20"
          : "bg-background/60 ring-1 ring-border hover:bg-background"
      }`}
    >
      <span
        className={`grid h-9 w-9 shrink-0 place-items-center rounded-full ${
          primary ? "bg-primary text-primary-foreground" : "bg-primary/15 text-primary"
        }`}
      >
        {icon}
      </span>
      <span className="min-w-0 flex-1">
        <span className="block truncate text-[13.5px] font-bold text-foreground">{label}</span>
        <span className="block truncate text-[11.5px] text-muted-foreground">{description}</span>
      </span>
      <ChevronRight className="h-4 w-4 shrink-0 text-muted-foreground" />
    </button>
  );
}



export const Route = createFileRoute("/passageiro/app")({
  head: () => ({ meta: [{ title: "MOVVI Drive — Passageiro" }] }),
  component: PassageiroApp,
});

type LatLng = { lat: number; lng: number };
type Suggestion = { placeId: string; primary: string; secondary: string };
type RideRow = Database["public"]["Tables"]["rides"]["Row"];
type DriverRow = Database["public"]["Tables"]["drivers"]["Row"];

const RECENT_KEY = "movvi.recent_destinations";

/**
 * Em qualquer ambiente não-produção (Lovable Preview / dev), forçamos a origem
 * a ser exibida como "Localização aproximada" mesmo que o Google retorne ROOFTOP.
 * Isso evita mostrar uma rua incorreta como se fosse o ponto exato do usuário
 * — comum em zonas rurais — quando o GPS do iframe é só um fallback por IP.
 */
const FORCE_APPROXIMATE_ORIGIN_IN_PREVIEW = true;

/** Distância em metros entre dois pares lat/lng (Haversine). */
function distanceMeters(a: LatLng, b: LatLng): number {
  const R = 6371000;
  const toRad = (d: number) => (d * Math.PI) / 180;
  const dLat = toRad(b.lat - a.lat);
  const dLng = toRad(b.lng - a.lng);
  const lat1 = toRad(a.lat);
  const lat2 = toRad(b.lat);
  const h =
    Math.sin(dLat / 2) ** 2 +
    Math.cos(lat1) * Math.cos(lat2) * Math.sin(dLng / 2) ** 2;
  return 2 * R * Math.asin(Math.sqrt(h));
}

/** Catálogo visual de categorias da MOVVI (mapeia para o enum backend). */
type UiCategory = {
  key: string;
  label: string;
  icon: LucideIcon;
  backend: RideCategory;
  tagline: string;
};
const UI_CATEGORIES: UiCategory[] = [
  { key: "carro",   label: "Carro",    icon: Car,     backend: "carros",  tagline: "Viagens urbanas com conforto" },
  { key: "moto",    label: "Moto",     icon: Bike,    backend: "motos",   tagline: "Viagens rápidas e econômicas" },
  { key: "entrega", label: "Entrega",  icon: Send,    backend: "envios",  tagline: "Envio de objetos e pequenos volumes" },
  { key: "guincho", label: "Guincho",  icon: Truck,   backend: "guincho", tagline: "Remoção e transporte de veículos" },
  { key: "mudanca", label: "Mudança",  icon: Box,     backend: "fretes",  tagline: "Transporte de móveis e cargas maiores" },
];

const fmtMin = (s: number) => `${Math.max(1, Math.round(s / 60))} min`;
const fmtKm = (m: number) =>
  m < 1000 ? `${Math.round(m)} m` : `${(m / 1000).toFixed(1)} km`;

function decodePolyline(encoded: string): LatLng[] {
  const points: LatLng[] = [];
  let index = 0,
    lat = 0,
    lng = 0;
  while (index < encoded.length) {
    let b,
      shift = 0,
      result = 0;
    do {
      b = encoded.charCodeAt(index++) - 63;
      result |= (b & 0x1f) << shift;
      shift += 5;
    } while (b >= 0x20);
    lat += result & 1 ? ~(result >> 1) : result >> 1;
    shift = 0;
    result = 0;
    do {
      b = encoded.charCodeAt(index++) - 63;
      result |= (b & 0x1f) << shift;
      shift += 5;
    } while (b >= 0x20);
    lng += result & 1 ? ~(result >> 1) : result >> 1;
    points.push({ lat: lat * 1e-5, lng: lng * 1e-5 });
  }
  return points;
}

type Recent = { label: string; secondary?: string; placeId: string };
type PassengerUiStage =
  | "selecting_destination"
  | "route_preview"
  | "selecting_category"
  | "confirming_request"
  | "searching_driver";

function PassageiroApp() {
  const navigate = useNavigate();
  const callComputeRoute = useServerFn(computeRoute);
  const callRequestRide = useServerFn(criarCorrida);
  const callCancelByPassenger = useServerFn(cancelarPeloPassageiro);
  const callReverseGeocode = useServerFn(reverseGeocode);

  const [userId, setUserId] = useState<string | null>(null);
  const [userName, setUserName] = useState<string>("");

  const [position, setPosition] = useState<LatLng | null>(null);
  const [gpsAccuracy, setGpsAccuracy] = useState<number | null>(null);
  const [geo, setGeo] = useState<GeocodeResult | null>(null);
  const [addressStatus, setAddressStatus] = useState<
    "idle" | "loading" | "resolved" | "failed"
  >("idle");
  const [addressDetailsOpen, setAddressDetailsOpen] = useState(false);
  const [originPickOnMap, setOriginPickOnMap] = useState(false);
  const [originManualOpen, setOriginManualOpen] = useState(false);
  const [originPickCenter, setOriginPickCenter] = useState<LatLng | null>(null);
  const [tick, setTick] = useState(0); // re-render para saudação dinâmica
  const [gpsState, setGpsState] = useState<
    "idle" | "requesting" | "granted" | "denied" | "unavailable"
  >("idle");
  const [gpsErrorMsg, setGpsErrorMsg] = useState<string>("");
  // 🔧 Painel temporário de diagnóstico de geolocalização (DEV)
  const [gpsDiag, setGpsDiag] = useState<{
    status: "ok" | "rejected-outside-br";
    lat: number;
    lng: number;
    accuracy: number | null;
    altitude: number | null;
    heading: number | null;
    speed: number | null;
    timestamp: number;
    reason?: string;
  } | null>(null);
  // Status da permissão de geolocalização (Permissions API).
  // - checking: ainda consultando a Permissions API
  // - prompt: navegador ainda não decidiu — precisa de ação do usuário
  // - granted: usuário já liberou; podemos pedir GPS imediatamente
  // - denied: usuário negou; mostrar fluxo manual
  // - unsupported: Permissions API ausente (Safari antigo etc.) — tratamos como "prompt"
  const [permissionStatus, setPermissionStatus] = useState<
    "checking" | "prompt" | "granted" | "denied" | "unsupported"
  >("checking");
  
  

  const [destinationText, setDestinationText] = useState("");
  const [suggestions, setSuggestions] = useState<Suggestion[]>([]);
  const [destination, setDestination] = useState<{
    point: LatLng;
    label: string;
  } | null>(null);
  const [route, setRoute] = useState<RouteResult | null>(null);
  const [passengerUiStage, setPassengerUiStage] = useState<PassengerUiStage>("selecting_destination");
  const [selectedCategoryKey, setSelectedCategoryKey] = useState<string | null>(null);
  const selectedUiCategory = useMemo(
    () => UI_CATEGORIES.find((c) => c.key === selectedCategoryKey) ?? null,
    [selectedCategoryKey],
  );
  const category: RideCategory = selectedUiCategory?.backend ?? "carros";
  const [recent, setRecent] = useState<Recent[]>([]);
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const [tariffs, setTariffs] = useState<TariffMap>({});

  /* ---------------------- tariffs (admin_settings) ---------------------- */
  useEffect(() => {
    let active = true;
    loadTariffs()
      .then((t) => {
        if (active) setTariffs(t);
      })
      .catch((e) => console.warn("[MOVVI] loadTariffs falhou:", e));
    return () => {
      active = false;
    };
  }, []);

  // ride lifecycle
  const [rideId, setRideId] = useState<string | null>(null);
  const [ride, setRide] = useState<RideRow | null>(null);
  const [driverInfo, setDriverInfo] = useState<DriverRow | null>(null);

  const mapRef = useRef<google.maps.Map | null>(null);
  const sessionTokenRef =
    useRef<google.maps.places.AutocompleteSessionToken | null>(null);
  const debounceRef = useRef<number | null>(null);
  const sheetRef = useRef<MovviSheetHandle | null>(null);
  const searchInputRef = useRef<HTMLInputElement | null>(null);

  const drivers = useNearbyDrivers({ category });

  // Conta apenas motoristas dentro do raio de 15 km da origem (mesmo raio do despacho).
  const nearbyCount = useMemo(() => {
    if (!position) return 0;
    const R = 6371;
    const toRad = (v: number) => (v * Math.PI) / 180;
    return drivers.filter((d) => {
      const dLat = toRad(d.current_lat - position.lat);
      const dLng = toRad(d.current_lng - position.lng);
      const a =
        Math.sin(dLat / 2) ** 2 +
        Math.cos(toRad(position.lat)) * Math.cos(toRad(d.current_lat)) * Math.sin(dLng / 2) ** 2;
      const km = 2 * R * Math.asin(Math.sqrt(a));
      return km <= 15;
    }).length;
  }, [drivers, position?.lat, position?.lng]);


  useEffect(() => {
    console.log("[MOVVI UI] etapa atual:", passengerUiStage);
  }, [passengerUiStage]);

  /* ---------------------- auth ---------------------- */
  useEffect(() => {
    supabase.auth.getUser().then(({ data }) => {
      if (!data.user) {
        navigate({ to: "/passageiro/login" });
        return;
      }
      setUserId(data.user.id);
      const meta = (data.user.user_metadata ?? {}) as Record<string, unknown>;
      setUserName(
        (meta.name as string) ||
          (meta.full_name as string) ||
          data.user.email?.split("@")[0] ||
          "Passageiro",
      );
    });
  }, [navigate]);

  /* ---------------------- recents (localStorage) ---------------------- */
  useEffect(() => {
    try {
      const raw = localStorage.getItem(RECENT_KEY);
      if (raw) setRecent(JSON.parse(raw));
    } catch {
      /* ignore */
    }
  }, []);

  function pushRecent(r: Recent) {
    setRecent((prev) => {
      const next = [r, ...prev.filter((x) => x.placeId !== r.placeId)].slice(0, 5);
      try {
        localStorage.setItem(RECENT_KEY, JSON.stringify(next));
      } catch {
        /* ignore */
      }
      return next;
    });
  }

  /* ---------------------- reverse geocode (endereço atual) ---------------------- */
  const lastGeocodedRef = useRef<LatLng | null>(null);
  useEffect(() => {
    if (!position) return;
    const last = lastGeocodedRef.current;
    if (
      last &&
      Math.abs(last.lat - position.lat) < 0.002 &&
      Math.abs(last.lng - position.lng) < 0.002
    )
      return;
    lastGeocodedRef.current = position;
    let active = true;
    setAddressStatus("loading");
    console.log("[MOVVI] Reverse geocoding iniciado");
    // Timeout de segurança: nunca deixar o cartão preso em "Obtendo localização...".
    const timeoutId = window.setTimeout(() => {
      if (!active) return;
      console.warn("[MOVVI] Timeout de localização aplicado");
      setAddressStatus((s) => (s === "loading" ? "failed" : s));
    }, 8000);
    callReverseGeocode({ data: { lat: position.lat, lng: position.lng } })
      .then((r) => {
        if (!active) return;
        const inPreview = isDevelopmentEnvironment();
        const hasRoute = !!r.components.rua;
        const hasNumber = !!r.components.numero;
        const fa = (r.address || "").toLowerCase();
        const addressMentionsStreet =
          hasRoute && (fa.includes((r.components.rua || "").toLowerCase()) || fa.match(/\d/) !== null);
        // Resultados muito genéricos: apenas locality / political → não é endereço de rua.
        const genericTypes = new Set(["locality", "political", "administrative_area_level_2", "administrative_area_level_1", "country", "plus_code"]);
        const looksGeneric = r.types.length > 0 && r.types.every((t) => genericTypes.has(t));

        let dist = Number.POSITIVE_INFINITY;
        if (typeof r.geocodedLat === "number" && typeof r.geocodedLng === "number") {
          dist = distanceMeters(position, { lat: r.geocodedLat, lng: r.geocodedLng });
        }

        const baseHighConfidence =
          r.locationType === "ROOFTOP" &&
          !r.partialMatch &&
          hasRoute &&
          hasNumber &&
          addressMentionsStreet &&
          !looksGeneric &&
          dist < 30;

        const highConfidence = inPreview && FORCE_APPROXIMATE_ORIGIN_IN_PREVIEW ? false : baseHighConfidence;
        const finalPrecision: "exact" | "approximate" = highConfidence ? "exact" : "approximate";

        console.log("[MOVVI] Endereço retornado pelo Google:", r.address || "(vazio)");
        console.log("[MOVVI] Tipo de precisão:", r.locationType || "(desconhecido)", r.partialMatch ? "(partial_match)" : "");
        console.log("[MOVVI] Distância entre GPS e geocoding:", Number.isFinite(dist) ? `${dist.toFixed(1)} m` : "n/d");
        console.log("[MOVVI] Preview detectado:", inPreview);
        console.log("[MOVVI] Alta confiança:", highConfidence, baseHighConfidence === highConfidence ? "" : "(rebaixado pelo preview)");
        if (finalPrecision === "approximate") {
          console.log("[MOVVI] Exibindo origem aproximada:", `${position.lat.toFixed(6)}, ${position.lng.toFixed(6)}`, r.region || "(sem referência)");
        }
        console.log("[MOVVI] Coordenadas reais mantidas para rota:", position.lat, position.lng);

        setGeo({ ...r, precision: finalPrecision });
        setAddressStatus("resolved");
      })
      .catch((e) => {
        if (!active) return;
        console.error("[MOVVI] Reverse geocoding falhou", e);
        setAddressStatus("failed");
      })
      .finally(() => {
        window.clearTimeout(timeoutId);
      });
    return () => {
      active = false;
      window.clearTimeout(timeoutId);
    };
  }, [position, callReverseGeocode]);

  // Atualiza saudação a cada minuto.
  useEffect(() => {
    const id = window.setInterval(() => setTick((t) => t + 1), 60_000);
    return () => window.clearInterval(id);
  }, []);
  void tick;

  /* ---------------------- GPS ---------------------- */
  // REGRA: nenhuma cidade fixa pode ser usada como fallback. Se o GPS falhar
  // ou retornar uma coordenada fora do Brasil, o app deve exibir "Localização
  // indisponível" e oferecer a entrada manual (Google Places).

  const gpsStateRef = useRef(gpsState);
  useEffect(() => {
    gpsStateRef.current = gpsState;
  }, [gpsState]);
  const watchIdRef = useRef<number | null>(null);
  const gpsRequestInFlightRef = useRef(false);

  const requestGps = useCallback(() => {
    // Guarda: não permitir cliques duplicados enquanto há uma solicitação em curso.
    if (gpsStateRef.current === "requesting" || gpsRequestInFlightRef.current) {
      console.log("[MOVVI] Ignorando clique — já existe uma solicitação de GPS em andamento.");
      return;
    }
    console.log("[MOVVI] Solicitando localização...");
    const fail = (msg: string) => {
      setGpsState("unavailable");
      gpsStateRef.current = "unavailable";
      setGpsErrorMsg(msg);
      gpsRequestInFlightRef.current = false;
    };
    if (!("geolocation" in navigator)) {
      fail("Seu navegador não oferece geolocalização.");
      return;
    }
    setGpsState("requesting");
    gpsStateRef.current = "requesting";
    gpsRequestInFlightRef.current = true;
    setGpsErrorMsg("");

    const onSuccess = (pos: GeolocationPosition) => {
      gpsRequestInFlightRef.current = false;
      const lat = pos.coords.latitude;
      const lng = pos.coords.longitude;
      console.log("[MOVVI] GPS recebido:", lat, lng, "accuracy:", pos.coords.accuracy);

      const insideBR = isBrazilCoordinate(lat, lng);
      if (!insideBR) {
        console.warn("[MOVVI] Aviso: coordenada fora do Brasil — aceitando mesmo assim.", { lat, lng });
        setGpsErrorMsg(
          "Sua localização parece estar fora do Brasil. Você pode digitar a origem manualmente se preferir.",
        );
      } else {
        setGpsErrorMsg("");
      }

      setPosition({ lat, lng });
      setGpsAccuracy(pos.coords.accuracy ?? null);
      setGpsDiag({
        status: insideBR ? "ok" : "rejected-outside-br",
        lat,
        lng,
        accuracy: pos.coords.accuracy ?? null,
        altitude: pos.coords.altitude ?? null,
        heading: pos.coords.heading ?? null,
        speed: pos.coords.speed ?? null,
        timestamp: pos.timestamp,
        reason: insideBR ? undefined : "Fora do bounding box do Brasil (aviso)",
      });
      setGpsState("granted");
      gpsStateRef.current = "granted";

      if (watchIdRef.current != null) {
        navigator.geolocation.clearWatch(watchIdRef.current);
      }
      watchIdRef.current = navigator.geolocation.watchPosition(
        (p) => {
          const la = p.coords.latitude;
          const ln = p.coords.longitude;
          setPosition({ lat: la, lng: ln });
          setGpsAccuracy(p.coords.accuracy ?? null);
        },
        () => undefined,
        { enableHighAccuracy: true, maximumAge: 5000, timeout: 20000 },
      );
    };

    const tryLowAccuracy = () => {
      console.log("[MOVVI] Tentativa 2 — enableHighAccuracy:false");
      try {
        navigator.geolocation.getCurrentPosition(
          onSuccess,
          (err) => {
            gpsRequestInFlightRef.current = false;
            console.error("[MOVVI] Erro (low accuracy):", err);
            setGpsState("denied");
            gpsStateRef.current = "denied";
            if (err.code === err.PERMISSION_DENIED) {
              setGpsErrorMsg("Permissão de localização negada.");
            } else {
              setGpsErrorMsg(
                "Não foi possível obter sua localização. Você pode digitar a origem manualmente ou tentar novamente.",
              );
            }
          },
          { enableHighAccuracy: false, maximumAge: 30000, timeout: 20000 },
        );
      } catch (e) {
        gpsRequestInFlightRef.current = false;
        console.error("[MOVVI] Falha 2ª tentativa:", e);
        fail("Não foi possível obter sua localização. Use a localização manual.");
      }
    };

    try {
      navigator.geolocation.getCurrentPosition(
        onSuccess,
        (err) => {
          console.warn("[MOVVI] Erro (high accuracy):", err);
          if (err.code === err.PERMISSION_DENIED) {
            gpsRequestInFlightRef.current = false;
            setGpsState("denied");
            gpsStateRef.current = "denied";
            setGpsErrorMsg("Permissão de localização negada.");
            return;
          }
          // Timeout ou POSITION_UNAVAILABLE → tenta de novo sem alta precisão.
          tryLowAccuracy();
        },
        { enableHighAccuracy: true, maximumAge: 10000, timeout: 20000 },
      );
    } catch (e) {
      console.error("[MOVVI] Falha ao iniciar geolocalização:", e);
      tryLowAccuracy();
    }
  }, []);


  useEffect(() => {
    return () => {
      if (watchIdRef.current != null) {
        navigator.geolocation.clearWatch(watchIdRef.current);
      }
    };
  }, []);



  const setManualLocation = useCallback((p: LatLng) => {
    if (!isBrazilCoordinate(p.lat, p.lng)) {
      console.warn("[MOVVI] Origem manual fora do Brasil — aceitando assim mesmo.", p);
    }
    console.log("[MOVVI] Origem manual selecionada", p);
    setPosition(p);
    setGpsState("granted");
    gpsStateRef.current = "granted";
    setGpsErrorMsg("");
  }, []);



  // Verifica a permissão de geolocalização ANTES de chamar getCurrentPosition.
  // - Se já estiver "granted", pedimos o GPS imediatamente (sem prompt do navegador).
  // - Se for "prompt" / Permissions API indisponível, NÃO pedimos nada agora —
  //   o usuário precisa tocar em "Permitir localização" para acionar o prompt
  //   oficial do navegador.
  // - Se for "denied", mostramos o fluxo manual sem nunca tentar de novo
  //   automaticamente (evita loops).
  useEffect(() => {
    purgeForeignMapCache();
    let cancelled = false;

    if (typeof navigator === "undefined" || !("geolocation" in navigator)) {
      setPermissionStatus("unsupported");
      setGpsState("unavailable");
      setGpsErrorMsg("Seu navegador não oferece geolocalização.");
      return;
    }

    const perms = (navigator as Navigator).permissions;
    if (!perms || typeof perms.query !== "function") {
      // Sem Permissions API (Safari iOS antigo etc.): tratamos como prompt,
      // o usuário precisa tocar no botão para disparar a solicitação.
      setPermissionStatus("unsupported");
      return;
    }

    let statusRef: PermissionStatus | null = null;
    perms
      .query({ name: "geolocation" as PermissionName })
      .then((status) => {
        if (cancelled) return;
        statusRef = status;
        const apply = (s: PermissionState) => {
          if (s === "granted") {
            setPermissionStatus("granted");
            // Permissão já concedida em qualquer ambiente (inclusive preview):
            // tentamos obter o GPS real imediatamente. Se vier coordenada inválida
            // (fora do Brasil) o próprio requestGps cai para o fluxo manual.
            requestGps();
          } else if (s === "denied") {
            setPermissionStatus("denied");
            setGpsState("denied");
            setGpsErrorMsg("Permissão de localização negada.");
          } else {
            setPermissionStatus("prompt");
          }
        };
        apply(status.state);
        status.onchange = () => apply(status.state);
      })
      .catch(() => {
        if (cancelled) return;
        setPermissionStatus("unsupported");
      });

    return () => {
      cancelled = true;
      if (statusRef) statusRef.onchange = null;
    };
  }, [requestGps]);


  /* ---------------------- autocomplete (Places API New) ---------------------- */
  useEffect(() => {
    if (debounceRef.current) window.clearTimeout(debounceRef.current);
    const q = destinationText.trim();
    if (q.length < 2 || destination) {
      setSuggestions([]);
      return;
    }
    debounceRef.current = window.setTimeout(async () => {
      try {
        const places = (await google.maps.importLibrary(
          "places",
        )) as google.maps.PlacesLibrary;
        if (!sessionTokenRef.current)
          sessionTokenRef.current = new places.AutocompleteSessionToken();
        const req: google.maps.places.AutocompleteRequest = {
          input: q,
          sessionToken: sessionTokenRef.current,
          language: "pt-BR",
          region: "br",
          includedRegionCodes: ["br"],
        };
        if (position)
          req.locationBias = {
            center: new google.maps.LatLng(position.lat, position.lng),
            radius: 50000,
          } as google.maps.CircleLiteral;
        const { suggestions: result } =
          await places.AutocompleteSuggestion.fetchAutocompleteSuggestions(req);
        setSuggestions(
          result
            .map((s) => s.placePrediction)
            .filter((p): p is google.maps.places.PlacePrediction => !!p)
            .slice(0, 6)
            .map((p) => ({
              placeId: p.placeId,
              primary: p.mainText?.toString() ?? p.text.toString(),
              secondary: p.secondaryText?.toString() ?? "",
            })),
        );
      } catch (e) {
        console.error("autocomplete error", e);
      }
    }, 220);
    return () => {
      if (debounceRef.current) window.clearTimeout(debounceRef.current);
    };
  }, [destinationText, position, destination]);

  async function pickSuggestion(s: Suggestion) {
    setError(null);
    try {
      const places = (await google.maps.importLibrary(
        "places",
      )) as google.maps.PlacesLibrary;
      const place = new places.Place({ id: s.placeId });
      await place.fetchFields({
        fields: ["location", "formattedAddress", "displayName"],
      });
      const loc = place.location;
      if (!loc) throw new Error("Local sem coordenadas.");
      const point: LatLng = { lat: loc.lat(), lng: loc.lng() };
      const label = place.formattedAddress ?? `${s.primary} ${s.secondary}`.trim();
      setDestination({ point, label });
      setDestinationText(label);
      setSuggestions([]);
      sessionTokenRef.current = null;
      pushRecent({ placeId: s.placeId, label: s.primary, secondary: s.secondary });
      sheetRef.current?.snapTo(55);
      searchInputRef.current?.blur();
      await calcRoute(point);
    } catch (e) {
      setError(e instanceof Error ? e.message : "Falha ao buscar o local.");
    }
  }

  async function calcRoute(dest: LatLng) {
    // REGRA: a origem é SEMPRE as coordenadas reais do GPS. Texto de endereço
    // serve apenas para exibição — nunca como origem da rota.
    if (
      !position ||
      !Number.isFinite(position.lat) ||
      !Number.isFinite(position.lng) ||
      !isBrazilCoordinate(position.lat, position.lng) ||
      !dest ||
      !Number.isFinite(dest.lat) ||
      !Number.isFinite(dest.lng) ||
      !isBrazilCoordinate(dest.lat, dest.lng)
    ) {
      setError(
        "Não foi possível calcular a rota. Confirme a localização de origem e destino.",
      );
      return;
    }
    setBusy(true);
    setError(null);
    setRoute(null);
    setSelectedCategoryKey(null);
    setPassengerUiStage("route_preview");
    try {
      const result = await callComputeRoute({
        data: {
          origin: { lat: position.lat, lng: position.lng },
          destination: { lat: dest.lat, lng: dest.lng },
        },
      });
      console.log("[MOVVI UI] rota calculada:", result);
      setRoute(result);
      setPassengerUiStage("route_preview");
      sheetRef.current?.snapTo(70);
      if (mapRef.current) {
        const bounds = new google.maps.LatLngBounds();
        bounds.extend(position);
        bounds.extend(dest);
        mapRef.current.fitBounds(bounds, { top: 100, bottom: window.innerHeight * 0.6, left: 60, right: 60 });
      }
    } catch (e) {
      setError(e instanceof Error ? e.message : "Falha ao calcular rota.");
    } finally {
      setBusy(false);
    }
  }

  function clearDestination() {
    setDestination(null);
    setDestinationText("");
    setRoute(null);
    setError(null);
    setSelectedCategoryKey(null);
    setPassengerUiStage("selecting_destination");
    setSuggestions([]);
    sheetRef.current?.snapTo(32);
    if (mapRef.current && position) {
      mapRef.current.panTo(position);
      mapRef.current.setZoom(16);
    }
  }

  async function submitRide() {
    if (!position || !destination || !route) return;
    if (!selectedUiCategory) {
      setError("Escolha uma categoria antes de solicitar a MOVVI.");
      setPassengerUiStage("selecting_category");
      sheetRef.current?.snapTo(70);
      return;
    }
    if (
      !isBrazilCoordinate(position.lat, position.lng) ||
      !isBrazilCoordinate(destination.point.lat, destination.point.lng)
    ) {
      setError(
        "Não foi possível calcular a rota. Confirme a localização de origem e destino.",
      );
      return;
    }
    setBusy(true);
    setError(null);
    try {
      const km = route.distanceMeters / 1000;
      const min = route.durationSeconds / 60;
      const fare = estimateFare(selectedUiCategory.backend, km, min, tariffs);
      // Texto da origem — apenas para exibição. As coordenadas reais é que
      // vão para o cálculo/rastreio. Se o Google não tiver nome, usamos as
      // coordenadas como rótulo.
      const originLabel =
        geo?.friendly ||
        geo?.region ||
        `GPS ${position.lat.toFixed(6)}, ${position.lng.toFixed(6)}`;
      const { rideId: newId } = await callRequestRide({
        data: {
          origin: { lat: position.lat, lng: position.lng },
          origin_name: originLabel,
          destination: { lat: destination.point.lat, lng: destination.point.lng },
          destination_name: destination.label,
          category: selectedUiCategory.backend,
          distance_km: Math.round(km * 100) / 100,
          duration_min: Math.round(min),
          estimated_price: fare,
        },
      });
      setRideId(newId);
      setPassengerUiStage("searching_driver");
    } catch (e) {
      setError(e instanceof Error ? e.message : "Falha ao solicitar corrida.");
    } finally {
      setBusy(false);
    }
  }

  /* ---------------------- realtime ---------------------- */
  useEffect(() => {
    if (!rideId) return;
    let active = true;
    let pollTimer: number | null = null;
    let subscribed = false;

    const load = async (tag: string) => {
      const { data, error } = await supabase
        .from("rides")
        .select("*")
        .eq("id", rideId)
        .maybeSingle();
      if (!active) return;
      if (error) {
        console.warn("[MOVVI PASSAGEIRO] erro ao recarregar corrida:", tag, error.message);
        return;
      }
      if (data) {
        setRide((prev) => {
          if (prev && prev.id === data.id && prev.status !== data.status) {
            console.log("[MOVVI PASSAGEIRO] status atualizou:", prev.status, "→", data.status);
          }
          return data;
        });
      }
    };

    const stopPolling = () => {
      if (pollTimer != null) {
        window.clearInterval(pollTimer);
        pollTimer = null;
      }
    };
    const startPolling = () => {
      if (pollTimer != null || !active) return;
      console.log("[MOVVI PASSAGEIRO] polling de segurança da corrida ativo");
      pollTimer = window.setInterval(() => { void load("poll"); }, 3500);
    };

    void load("init");
    startPolling();

    const ch = supabase
      .channel(`ride-${rideId}`)
      .on(
        "postgres_changes",
        { event: "UPDATE", schema: "public", table: "rides", filter: `id=eq.${rideId}` },
        (p) => {
          const next = p.new as RideRow;
          console.log("[MOVVI PASSAGEIRO] realtime UPDATE rides:", next.id, "status=", next.status);
          setRide(next);
        },
      )
      .subscribe((status) => {
        console.log("[MOVVI PASSAGEIRO] canal ride-" + rideId + " status:", status);
        if (status === "SUBSCRIBED") {
          subscribed = true;
          // recarrega para capturar updates ocorridos durante o handshake;
          // o polling de segurança permanece ativo para não deixar o passageiro preso em "procurando".
          void load("subscribed");
        } else if (status === "CHANNEL_ERROR" || status === "TIMED_OUT" || status === "CLOSED") {
          subscribed = false;
          startPolling();
        }
      });

    // Só liga polling se o canal não ficou SUBSCRIBED em 5s.
    const handshakeGuard = window.setTimeout(() => {
      if (!subscribed) startPolling();
    }, 5000);

    return () => {
      active = false;
      window.clearTimeout(handshakeGuard);
      stopPolling();
      supabase.removeChannel(ch);
    };
  }, [rideId]);


  useEffect(() => {
    const driverId = ride?.driver_id;
    if (!driverId) {
      setDriverInfo(null);
      return;
    }
    let cancelled = false;
    let pollTimer: number | null = null;
    let subscribed = false;

    const load = () => {
      supabase
        .from("drivers")
        .select("*")
        .eq("user_id", driverId)
        .maybeSingle()
        .then(({ data }) => {
          if (!cancelled && data) setDriverInfo((prev) => ({ ...(prev ?? data), ...data }));
        });
    };
    const stopPolling = () => {
      if (pollTimer != null) {
        window.clearInterval(pollTimer);
        pollTimer = null;
      }
    };
    const startPolling = () => {
      if (pollTimer != null || cancelled) return;
      console.log("[MOVVI PASSAGEIRO] fallback polling motorista (realtime indisponível)");
      pollTimer = window.setInterval(load, 15000);
    };

    load();

    const ch = supabase
      .channel(`driver-track-${driverId}`)
      .on(
        "postgres_changes",
        { event: "UPDATE", schema: "public", table: "drivers", filter: `user_id=eq.${driverId}` },
        (p) => {
          const next = p.new as DriverRow;
          setDriverInfo((prev) => ({ ...(prev ?? next), ...next }));
        },
      )
      .subscribe((status) => {
        if (status === "SUBSCRIBED") {
          subscribed = true;
          stopPolling();
        } else if (status === "CHANNEL_ERROR" || status === "TIMED_OUT" || status === "CLOSED") {
          subscribed = false;
          startPolling();
        }
      });

    const handshakeGuard = window.setTimeout(() => {
      if (!subscribed) startPolling();
    }, 5000);

    return () => {
      cancelled = true;
      window.clearTimeout(handshakeGuard);
      stopPolling();
      supabase.removeChannel(ch);
    };
  }, [ride?.driver_id]);

  function resetRide() {
    setRideId(null);
    setRide(null);
    setDriverInfo(null);
    clearDestination();
  }

  async function cancelRide() {
    if (!ride) return;
    try {
      await callCancelByPassenger({ data: { rideId: ride.id } });
    } catch (err) {
      console.error("[MOVVI] cancelarPeloPassageiro falhou:", err);
    }
    resetRide();
  }

  async function handleLogout() {
    await supabase.auth.signOut();
    navigate({ to: "/" });
  }

  function recenter() {
    if (mapRef.current && position) {
      mapRef.current.panTo(position);
      mapRef.current.setZoom(16);
    }
  }

  function focusSearch() {
    sheetRef.current?.snapTo(70);
    setTimeout(() => searchInputRef.current?.focus(), 220);
  }

  const polyPath = useMemo(
    () => (route ? decodePolyline(route.encodedPolyline) : []),
    [route],
  );

  const center = position && isBrazilCoordinate(position.lat, position.lng) ? position : BRAZIL_CENTER;
  const phase = ride?.status;
  const rideDriverInfo = useMemo<DriverRow | null>(() => {
    if (driverInfo) return driverInfo;
    if (!ride?.driver_id && !ride?.driver_name) return null;

    const vehicleParts = (ride.driver_vehicle ?? "")
      .split(" • ")
      .map((part) => part.trim())
      .filter(Boolean);
    const vehiclePlate = vehicleParts.length >= 1 ? vehicleParts[vehicleParts.length - 1] : "";
    const vehicleModel = vehicleParts.length >= 2 ? vehicleParts[vehicleParts.length - 2] : ride.driver_vehicle ?? "";
    const vehicleColor = vehicleParts.length >= 3 ? vehicleParts[0] : "";

    return {
      user_id: ride.driver_id ?? "",
      name: ride.driver_name ?? "Motorista MOVVI",
      phone: ride.driver_phone ?? "",
      current_lat: ride.driver_lat,
      current_lng: ride.driver_lng,
      current_heading: null,
      current_speed: null,
      rating: 5,
      selfie_url: null,
      vehicle_color: vehicleColor,
      vehicle_model: vehicleModel,
      vehicle_plate: vehiclePlate,
    } as DriverRow;
  }, [driverInfo, ride?.driver_id, ride?.driver_name, ride?.driver_phone, ride?.driver_vehicle, ride?.driver_lat, ride?.driver_lng]);

  /* ---------------------- GPS initial loading ---------------------- */
  // Padrão Uber/99/InDrive:
  //  1) Enquanto a Permissions API ainda responde, mostramos um loader curto.
  //  2) Se a permissão é "prompt" / desconhecida → tela explicativa com botão
  //     "Permitir localização" (só aí chamamos getCurrentPosition).
  //  3) Se foi negada / indisponível → tela com retry + localização manual.
  //  4) Se concedida → o app abre normalmente assim que as coordenadas chegam.
  if (!position && permissionStatus === "checking") {
    return (
      <div className="flex min-h-[100dvh] items-center justify-center bg-background text-foreground">
        <div className="flex flex-col items-center gap-3">
          <div className="h-10 w-10 rounded-full border-2 border-primary border-t-transparent animate-spin" />
          <p className="text-sm text-muted-foreground">Preparando a MOVVI...</p>
        </div>
      </div>
    );
  }

  // Quando a permissão já está concedida e estamos só esperando o GPS responder,
  // mostramos um loader curto em vez da tela de "permitir localização".
  if (
    !position &&
    permissionStatus === "granted" &&
    gpsState !== "denied" &&
    gpsState !== "unavailable"
  ) {
    return (
      <div className="mx-auto flex h-[100dvh] w-full max-w-[430px] items-center justify-center bg-background text-foreground">
        <div className="flex flex-col items-center gap-3">
          <div className="h-10 w-10 rounded-full border-2 border-primary border-t-transparent animate-spin" />
          <p className="text-sm text-muted-foreground">Obtendo sua localização...</p>
        </div>
      </div>
    );
  }

  // Permissão pendente (prompt) e ainda não tentamos nada → tela de explicação.
  // Se o GPS falhou ou foi negado mas o usuário já interagiu, NÃO bloqueamos
  // mais a tela: deixamos o app abrir com o mapa centralizado no Brasil e
  // permitimos digitar a origem manualmente.
  if (!position && (permissionStatus === "prompt" || permissionStatus === "unsupported") && gpsState === "idle") {
    return (
      <GpsDeniedScreen
        mode="prompt"
        onRetry={requestGps}
        onHome={() => { void navigate({ to: "/" }); }}
        onManual={setManualLocation}
        errorMessage={gpsErrorMsg}
        requesting={false}
      />
    );

  }
  const gpsFailed = (gpsState === "denied" || gpsState === "unavailable") && !!gpsErrorMsg;




  const inPreview = DEV_MODE && isDevelopmentEnvironment();
  return (
    <div className="relative mx-auto h-[100dvh] w-full max-w-[430px] overflow-hidden bg-background text-foreground shadow-2xl sm:my-0">

      {inPreview && (
        <div
          className="pointer-events-none absolute inset-x-0 top-0 z-50 flex justify-center px-3 pt-[max(env(safe-area-inset-top),0px)]"
        >
          <div className="pointer-events-auto mt-2 max-w-[92%] rounded-full bg-amber-500/15 px-3 py-1.5 text-center text-[11px] font-medium text-amber-300 ring-1 ring-amber-500/30 backdrop-blur">
            Ambiente de teste detectado. A localização real pode não funcionar aqui.
          </div>
        </div>
      )}
      {DEV_MODE && gpsDiag && (
        <div className="pointer-events-auto absolute left-2 top-14 z-50 max-w-[280px] rounded-lg bg-black/85 p-3 font-mono text-[10px] leading-tight text-white ring-1 ring-white/20 backdrop-blur">
          <div className="mb-1 flex items-center justify-between gap-2">
            <span className={`font-bold ${gpsDiag.status === "ok" ? "text-emerald-400" : "text-red-400"}`}>
              {gpsDiag.status === "ok" ? "🛰️ GPS OK" : "⛔ GPS REJEITADO"}
            </span>
            <button
              onClick={() => setGpsDiag(null)}
              className="rounded px-1.5 text-white/60 hover:text-white"
              aria-label="Fechar"
            >
              ✕
            </button>
          </div>
          {gpsDiag.status === "rejected-outside-br" ? (
            <div className="space-y-0.5">
              <div>Latitude recebida: {gpsDiag.lat.toFixed(6)}</div>
              <div>Longitude recebida: {gpsDiag.lng.toFixed(6)}</div>
              <div>Accuracy: {gpsDiag.accuracy != null ? `${Math.round(gpsDiag.accuracy)} m` : "—"}</div>
              <div>Motivo: {gpsDiag.reason}</div>
            </div>
          ) : (
            <div className="space-y-0.5">
              <div>Latitude: {gpsDiag.lat.toFixed(6)}</div>
              <div>Longitude: {gpsDiag.lng.toFixed(6)}</div>
              <div>Accuracy: {gpsDiag.accuracy != null ? `${Math.round(gpsDiag.accuracy)} m` : "—"}</div>
              <div>Altitude: {gpsDiag.altitude != null ? `${gpsDiag.altitude.toFixed(1)} m` : "—"}</div>
              <div>Heading: {gpsDiag.heading != null ? `${gpsDiag.heading.toFixed(1)}°` : "—"}</div>
              <div>Speed: {gpsDiag.speed != null ? `${gpsDiag.speed.toFixed(2)} m/s` : "—"}</div>
              <div>Timestamp: {new Date(gpsDiag.timestamp).toISOString()}</div>
            </div>
          )}
          <div className="mt-2 border-t border-white/10 pt-1.5 text-white/60">
            <div className="truncate">UA: {typeof navigator !== "undefined" ? navigator.userAgent : ""}</div>
            <div>Platform: {typeof navigator !== "undefined" ? navigator.platform : ""}</div>
            <div>secureContext: {typeof window !== "undefined" && window.isSecureContext ? "true" : "false"}</div>
            <div className="truncate">origin: {typeof document !== "undefined" ? document.location.origin : ""}</div>
          </div>
        </div>
      )}
      {/* MAPA — sempre presente, ~70% da tela */}

      <div className="absolute inset-0">
        <MovviMap
          center={center}
          zoom={position ? 16 : 5}
          height="100%"
          onLoad={(m) => {
            mapRef.current = m;
          }}
        >
          {position && (
            <>
              <Circle
                center={position}
                radius={Math.max(40, gpsAccuracy ?? 60)}
                options={{
                  strokeColor: "#3b82f6",
                  strokeOpacity: 0.35,
                  strokeWeight: 1,
                  fillColor: "#3b82f6",
                  fillOpacity: 0.12,
                  clickable: false,
                }}
              />
              <PulsingUserMarker position={position} />
            </>
          )}

          {!ride &&
            drivers.map((d) => (
              <Marker
                key={d.user_id}
                position={{ lat: d.current_lat, lng: d.current_lng }}
                icon={{
                  path: "M5 11l1.5-4.5h11L19 11M6 14h12M7.5 17a1.5 1.5 0 1 1-3 0 1.5 1.5 0 0 1 3 0Zm12 0a1.5 1.5 0 1 1-3 0 1.5 1.5 0 0 1 3 0ZM5 11h14v4H5z",
                  fillColor: "#8DD92B",
                  fillOpacity: 1,
                  strokeColor: "#05070D",
                  strokeWeight: 1.4,
                  scale: 1.2,
                  anchor: new google.maps.Point(12, 14),
                }}
              />
            ))}

          {destination && (
            <Marker
              position={destination.point}
              icon={{
                path: "M12 2C8.13 2 5 5.13 5 9c0 5.25 7 13 7 13s7-7.75 7-13c0-3.87-3.13-7-7-7z",
                fillColor: "#ef4444",
                fillOpacity: 1,
                strokeColor: "#05070D",
                strokeWeight: 2,
                scale: 1.7,
                anchor: new google.maps.Point(12, 22),
              }}
            />
          )}

          {/* Marcador do motorista durante a corrida (rastreamento em tempo real) */}
          {ride &&
            (ride.status === "motorista_a_caminho" ||
              ride.status === "motorista_chegou" ||
              ride.status === "em_viagem") &&
            rideDriverInfo &&
            typeof rideDriverInfo.current_lat === "number" &&
            typeof rideDriverInfo.current_lng === "number" && (
              <Marker
                position={{ lat: rideDriverInfo.current_lat, lng: rideDriverInfo.current_lng }}
                icon={{
                  path: "M5 11l1.5-4.5h11L19 11M6 14h12M7.5 17a1.5 1.5 0 1 1-3 0 1.5 1.5 0 0 1 3 0Zm12 0a1.5 1.5 0 1 1-3 0 1.5 1.5 0 0 1 3 0ZM5 11h14v4H5z",
                  fillColor: "#8DD92B",
                  fillOpacity: 1,
                  strokeColor: "#05070D",
                  strokeWeight: 1.6,
                  scale: 1.6,
                  rotation: typeof rideDriverInfo.current_heading === "number" ? rideDriverInfo.current_heading : 0,
                  anchor: new google.maps.Point(12, 14),
                }}
                zIndex={9999}
              />
            )}

          {polyPath.length > 0 && (
            <Polyline
              path={polyPath}
              options={{
                strokeColor: "#8DD92B",
                strokeOpacity: 0.95,
                strokeWeight: 6,
                geodesic: true,
              }}
            />
          )}
        </MovviMap>
      </div>

      {/* TOP BAR — premium: saudação + status dinâmico */}
      <PremiumTopBar
        userName={userName}
        gpsState={gpsState}
        drivers={nearbyCount}
        searching={!!ride && ride.status === "procurar_motorista"}
        onLogout={handleLogout}
      />

      {/* Floating controls */}
      <div className="pointer-events-none absolute right-3 z-30" style={{ bottom: "calc(32vh + 12px)" }}>
        <button
          onClick={recenter}
          className="pointer-events-auto flex h-12 w-12 items-center justify-center rounded-full bg-card text-foreground shadow-2xl ring-1 ring-border transition active:scale-90 hover:scale-105"
          aria-label="Recentralizar"
        >
          <Crosshair className="h-5 w-5 text-primary" />
        </button>
      </div>

      {/* BOTTOM SHEET — novo, próprio do MOVVI */}
      {!ride && (
        <MovviSheet ref={sheetRef} snaps={[32, 55, 70]} initial={32}>
          <SheetContent
            geo={geo}
            addressStatus={addressStatus}
            hasPosition={!!position}
            position={position}
            onOpenAddressDetails={() => setAddressDetailsOpen(true)}
            destination={destination}
            destinationText={destinationText}
            setDestinationText={setDestinationText}
            suggestions={suggestions}
            onFocusSearch={focusSearch}
            onPick={pickSuggestion}
            onClearDestination={clearDestination}
            route={route}
            uiStage={passengerUiStage}
            setUiStage={setPassengerUiStage}
            busy={busy}
            error={error}
            selectedCategoryKey={selectedCategoryKey}
            setSelectedCategoryKey={setSelectedCategoryKey}
            driversCount={nearbyCount}
            tariffs={tariffs}
            onSubmit={submitRide}
            searchInputRef={searchInputRef}
            gpsFailed={gpsFailed}
            gpsErrorMsg={gpsErrorMsg}
            gpsRequesting={gpsState === "requesting"}
            onRetryGps={requestGps}
            onExpandSheet={(p) => sheetRef.current?.snapTo(p)}
          />
        </MovviSheet>
      )}

      {/* Sheet de ações para o Local de partida */}
      {addressDetailsOpen && (
        <OriginActionsSheet
          geo={geo}
          position={position}
          gpsRequesting={gpsState === "requesting"}
          onClose={() => setAddressDetailsOpen(false)}
          onUseGps={() => {
            setAddressDetailsOpen(false);
            requestGps();
          }}
          onPickOnMap={() => {
            setAddressDetailsOpen(false);
            setOriginPickCenter(position ?? BRAZIL_CENTER);
            setOriginPickOnMap(true);
            if (mapRef.current && position) {
              mapRef.current.panTo(position);
              mapRef.current.setZoom(17);
            }
          }}
          onTypeAddress={() => {
            setAddressDetailsOpen(false);
            setOriginManualOpen(true);
          }}
        />
      )}

      {/* Seletor no mapa — overlay com crosshair fixo + botão confirmar */}
      {originPickOnMap && (
        <OriginMapPickerOverlay
          mapRef={mapRef}
          initialCenter={originPickCenter ?? position ?? BRAZIL_CENTER}
          onCancel={() => setOriginPickOnMap(false)}
          onConfirm={(p) => {
            setOriginPickOnMap(false);
            setManualLocation(p);
          }}
        />
      )}

      {/* Busca manual de endereço para a origem */}
      {originManualOpen && (
        <OriginManualSearchOverlay
          onCancel={() => setOriginManualOpen(false)}
          onConfirm={(p) => {
            setOriginManualOpen(false);
            setManualLocation(p);
          }}
        />
      )}


      {ride && ride.status === "procurar_motorista" && (
        <MovviSheet snaps={[50]} initial={50}>
          <SearchingPanel
            category={category}
            driversCount={nearbyCount}
            onCancel={cancelRide}
          />
        </MovviSheet>
      )}

      {ride &&
        rideDriverInfo &&
        (phase === "motorista_a_caminho" ||
          phase === "motorista_chegou" ||
          phase === "em_viagem") && (
          <MovviSheet snaps={[40, 65]} initial={40}>
            <DriverEnRoute ride={ride} driver={rideDriverInfo} onCancel={cancelRide} />
          </MovviSheet>
        )}

      {ride && phase === "finalizada" && (
        <MovviSheet snaps={[40]} initial={40}>
          <div className="pt-2 text-center">
            <div className="mx-auto mb-3 inline-flex h-16 w-16 items-center justify-center rounded-2xl bg-primary/15 text-primary text-3xl">
              ✓
            </div>
            <h2 className="font-display text-xl font-bold">Viagem concluída</h2>
            {ride.final_price && (
              <p className="mt-1 text-2xl font-bold text-primary">
                {formatBRL(Number(ride.final_price))}
              </p>
            )}
            <button
              onClick={resetRide}
              className="mt-6 w-full rounded-2xl bg-primary py-4 text-sm font-bold text-primary-foreground shadow-lg shadow-primary/30"
            >
              Pedir outra corrida
            </button>
          </div>
        </MovviSheet>
      )}
    </div>
  );
}

/* ============================================================ */
/*                         SHEET CONTENT                        */
/* ============================================================ */

/* (Grupos antigos removidos — agora exibimos as 5 categorias flat conforme spec MOVVI.) */

function SheetContent({
  geo,
  addressStatus,
  hasPosition,
  position,
  onOpenAddressDetails,
  destination,
  destinationText,
  setDestinationText,
  suggestions,
  onFocusSearch,
  onPick,
  onClearDestination,
  route,
  uiStage,
  setUiStage,
  busy,
  error,
  selectedCategoryKey,
  setSelectedCategoryKey,
  driversCount,
  tariffs,
  onSubmit,
  searchInputRef,
  gpsFailed,
  gpsErrorMsg,
  gpsRequesting,
  onRetryGps,
  onExpandSheet,
}: {
  geo: GeocodeResult | null;
  addressStatus: "idle" | "loading" | "resolved" | "failed";
  hasPosition: boolean;
  position: LatLng | null;
  onOpenAddressDetails: () => void;
  destination: { point: LatLng; label: string } | null;
  destinationText: string;
  setDestinationText: (s: string) => void;
  suggestions: Suggestion[];
  onFocusSearch: () => void;
  onPick: (s: Suggestion) => void;
  onClearDestination: () => void;
  route: RouteResult | null;
  uiStage: PassengerUiStage;
  setUiStage: (stage: PassengerUiStage) => void;
  busy: boolean;
  error: string | null;
  selectedCategoryKey: string | null;
  setSelectedCategoryKey: (k: string | null) => void;
  driversCount: number;
  tariffs: TariffMap;
  onSubmit: () => void;
  searchInputRef: React.RefObject<HTMLInputElement | null>;
  gpsFailed: boolean;
  gpsErrorMsg: string;
  gpsRequesting: boolean;
  onRetryGps: () => void;
  onExpandSheet: (p: number) => void;
}) {
  const km = route ? route.distanceMeters / 1000 : 0;
  const min = route ? route.durationSeconds / 60 : 0;

  const selectedCategory = useMemo(
    () => UI_CATEGORIES.find((c) => c.key === selectedCategoryKey) ?? null,
    [selectedCategoryKey],
  );
  const selectedFare = route && selectedCategory
    ? estimateFare(selectedCategory.backend, km, min, tariffs)
    : null;


  const isExact = geo?.precision === "exact";
  const rua = geo?.components.rua;
  const numero = geo?.components.numero;
  const bairro = geo?.components.bairro || geo?.components.povoado;
  const region = geo?.region || "";
  // Só exibimos rua/número como origem se o Google indicou ROOFTOP sem partial_match.
  // Caso contrário (APPROXIMATE/GEOMETRIC_CENTER/RANGE_INTERPOLATED) mostramos coords + referência.
  const streetLine = isExact && rua ? (numero ? `${rua}, ${numero}` : rua) : "";
  const hasApproxAddress = !!geo && !isExact;
  const showApprox = hasApproxAddress && hasPosition && !!position;
  const showDestinationInput = !destination || uiStage === "selecting_destination";

  return (
    <div className="pt-1">
      {/* Endereço atual — toque abre sheet de ações. Em caso de falha de GPS, mostra erro inline com retry. */}
      {gpsFailed ? (
        <div className="mb-2.5 flex w-full items-start gap-2.5 rounded-2xl bg-destructive/10 px-3 py-2.5 ring-1 ring-destructive/40">
          <span className="grid h-7 w-7 shrink-0 place-items-center rounded-full bg-destructive/80 text-destructive-foreground">
            <MapPin className="h-3.5 w-3.5" />
          </span>
          <div className="min-w-0 flex-1">
            <div className="text-[9px] font-semibold uppercase tracking-widest text-destructive leading-none">
              Localização indisponível
            </div>
            <div className="mt-0.5 text-[12px] leading-snug text-foreground/90">
              {gpsErrorMsg || "Não foi possível identificar sua localização."}
            </div>
          </div>
          <button
            type="button"
            onClick={onRetryGps}
            disabled={gpsRequesting}
            className="shrink-0 self-center rounded-full bg-primary px-3 py-1.5 text-[11px] font-bold text-primary-foreground shadow-md shadow-primary/20 transition active:scale-95 disabled:opacity-60"
          >
            {gpsRequesting ? "..." : "Tentar novamente"}
          </button>
        </div>
      ) : (
        <button
          type="button"
          onClick={onOpenAddressDetails}
          className="mb-2.5 flex w-full items-center gap-2.5 rounded-2xl bg-primary/10 px-3 py-2 text-left ring-1 ring-primary/30 transition active:scale-[0.99] hover:bg-primary/15"
        >
          <span className="grid h-8 w-8 shrink-0 place-items-center rounded-full bg-primary text-primary-foreground">
            <MapPin className="h-4 w-4" />
          </span>
          <div className="min-w-0 flex-1">
            <div className="flex items-center justify-between gap-2">
              <div className="text-[9px] font-semibold uppercase tracking-widest text-primary leading-none">
                📍 Local de partida
              </div>
              {hasPosition && (
                <span className="text-[9px] font-bold uppercase tracking-wider text-primary/80">
                  Ajustar local
                </span>
              )}
            </div>
            {addressStatus === "loading" && !streetLine && !showApprox ? (
              <div className="mt-0.5 truncate text-[12px] font-medium leading-tight text-muted-foreground">
                Obtendo seu endereço...
              </div>
            ) : streetLine ? (
              <>
                <div className="mt-0.5 truncate text-[13.5px] font-bold leading-tight text-foreground">
                  {streetLine}
                </div>
                {bairro && (
                  <div className="truncate text-[12px] leading-tight text-foreground/80">
                    {bairro}
                  </div>
                )}
                {region && (
                  <div className="truncate text-[11.5px] font-medium leading-tight text-muted-foreground">
                    {region}
                  </div>
                )}
              </>
            ) : showApprox && position ? (
              <>
                <div className="mt-0.5 truncate text-[12.5px] font-bold leading-tight text-amber-400">
                  Localização aproximada
                </div>
                <div className="truncate font-mono text-[11.5px] leading-tight text-foreground">
                  Lat: {position.lat.toFixed(6)} • Lng: {position.lng.toFixed(6)}
                </div>
                {region && (
                  <div className="truncate text-[11.5px] leading-tight text-muted-foreground">
                    Referência: {region}
                  </div>
                )}
              </>
            ) : hasPosition && position ? (
              <div className="mt-0.5 truncate font-mono text-[12px] font-semibold text-foreground">
                {position.lat.toFixed(6)}, {position.lng.toFixed(6)}
              </div>
            ) : (
              <div className="mt-0.5 truncate text-[12px] font-medium leading-tight text-muted-foreground">
                Localização indisponível
              </div>
            )}
          </div>
          <ChevronRight className="h-4 w-4 shrink-0 text-muted-foreground" />
        </button>
      )}




      {/* "Para onde você vai?" — só aparece antes de confirmar um destino. */}
      {showDestinationInput && (
        <div className="mb-2">
          <div className="flex items-center gap-3 rounded-2xl bg-background/80 px-4 py-3.5 ring-1 ring-border focus-within:ring-primary/60">
            <Search className="h-5 w-5 shrink-0 text-primary" />
            <input
              ref={searchInputRef}
              value={destinationText}
              onChange={(e) => {
                if (destination) onClearDestination();
                setDestinationText(e.target.value);
              }}
              onFocus={onFocusSearch}
              placeholder="Para onde você vai?"
              className="min-w-0 flex-1 bg-transparent text-[15px] font-semibold outline-none placeholder:text-muted-foreground/80"
            />
            {destinationText && (
              <button
                type="button"
                onClick={() => {
                  setDestinationText("");
                  onClearDestination();
                  searchInputRef.current?.focus();
                }}
                aria-label="Limpar"
                className="rounded-full p-1 text-muted-foreground hover:bg-accent/30"
              >
                <X className="h-4 w-4" />
              </button>
            )}
          </div>
        </div>
      )}

      {/* Sugestões ao vivo */}
      {showDestinationInput && suggestions.length > 0 && !destination && (
        <ul className="-mx-1 mb-2 space-y-1">
          {suggestions.map((s) => (
            <li key={s.placeId}>
              <button
                type="button"
                onClick={() => onPick(s)}
                className="flex w-full items-start gap-3 rounded-xl px-3 py-3 text-left transition hover:bg-accent/30 active:scale-[0.99]"
              >
                <span className="mt-0.5 grid h-9 w-9 shrink-0 place-items-center rounded-full bg-primary/15 text-primary">
                  <MapPin className="h-4 w-4" />
                </span>
                <span className="flex min-w-0 flex-col">
                  <span className="truncate text-sm font-semibold">{s.primary}</span>
                  {s.secondary && (
                    <span className="truncate text-xs text-muted-foreground">
                      {s.secondary}
                    </span>
                  )}
                </span>
              </button>
            </li>
          ))}
        </ul>
      )}

      {/* SEM destino: dica discreta — sem categorias aqui */}
      {showDestinationInput && !destination && suggestions.length === 0 && (
        <div className="mb-1 mt-1 rounded-2xl border border-dashed border-border/70 bg-background/40 px-4 py-3 text-center">
          <p className="text-[12px] leading-snug text-muted-foreground">
            Informe o destino para ver as opções de{" "}
            <span className="font-semibold text-foreground">Corridas</span>,{" "}
            <span className="font-semibold text-foreground">Envios</span> e{" "}
            <span className="font-semibold text-foreground">Serviços</span>{" "}
            disponíveis no trajeto.
          </p>
        </div>
      )}

      {/* COM destino: fluxo em 4 etapas (estilo Uber/99/InDrive) */}
      {destination && (
        <StepFlow
          destination={destination}
          route={route}
          uiStage={uiStage}
          setUiStage={setUiStage}
          busy={busy}
          error={error}
          km={km}
          min={min}
          tariffs={tariffs}
          selectedCategoryKey={selectedCategoryKey}
          setSelectedCategoryKey={setSelectedCategoryKey}
          selectedCategory={selectedCategory}
          selectedFare={selectedFare}
          onClearDestination={onClearDestination}
          onSubmit={onSubmit}
          onExpandSheet={onExpandSheet}
        />
      )}
    </div>
  );
}

// ──────────────────────────────────────────────────────────────
// Fluxo em etapas após o destino
// ──────────────────────────────────────────────────────────────

type StepFlowProps = {
  destination: { point: LatLng; label: string };
  route: RouteResult | null;
  uiStage: PassengerUiStage;
  setUiStage: (stage: PassengerUiStage) => void;
  busy: boolean;
  error: string | null;
  km: number;
  min: number;
  tariffs: TariffMap;
  selectedCategoryKey: string | null;
  setSelectedCategoryKey: (k: string | null) => void;
  selectedCategory: UiCategory | null;
  selectedFare: number | null;
  onClearDestination: () => void;
  onSubmit: () => void;
  onExpandSheet: (p: number) => void;
};

function StepFlow({
  destination,
  route,
  uiStage,
  setUiStage,
  busy,
  error,
  km,
  min,
  tariffs,
  selectedCategoryKey,
  setSelectedCategoryKey,
  selectedCategory,
  selectedFare,
  onClearDestination,
  onSubmit,
  onExpandSheet,
}: StepFlowProps) {
  useEffect(() => {
    if (route && uiStage === "selecting_destination") setUiStage("route_preview");
  }, [route, uiStage, setUiStage]);

  useEffect(() => {
    if (uiStage === "selecting_category" || uiStage === "confirming_request") onExpandSheet(70);
  }, [uiStage, onExpandSheet]);

  useEffect(() => {
    if (uiStage === "selecting_category") {
      console.log("[MOVVI UI] exibindo categorias:", UI_CATEGORIES.map((c) => c.label));
    }
  }, [uiStage]);

  // Preço de prévia (categoria padrão = carro) para a Etapa 2
  const previewFare = route
    ? estimateFare(UI_CATEGORIES[0].backend, km, min, tariffs)
    : null;

  return (
    <div className="animate-in fade-in duration-200">
      {/* Cabeçalho do destino com voltar */}
      <div className="mb-3 flex items-center gap-2 rounded-xl bg-background/60 px-2.5 py-2 ring-1 ring-border">
        {(uiStage === "selecting_category" || uiStage === "confirming_request") && (
          <button
            type="button"
            onClick={() => {
              if (uiStage === "confirming_request") setUiStage("selecting_category");
              else setUiStage("route_preview");
            }}
            aria-label="Voltar"
            className="grid h-7 w-7 shrink-0 place-items-center rounded-full text-muted-foreground hover:bg-accent/40"
          >
            <ArrowLeft className="h-4 w-4" />
          </button>
        )}
        <MapPin className="h-4 w-4 shrink-0 text-destructive" />
        <span className="line-clamp-1 flex-1 text-[12.5px] font-medium">
          {destination.label}
        </span>
        <button
          onClick={onClearDestination}
          aria-label="Remover destino"
          className="rounded-full p-1 text-muted-foreground hover:bg-accent/40"
        >
          <X className="h-4 w-4" />
        </button>
      </div>

      {error && (
        <p className="mb-2 rounded-xl bg-destructive/15 px-3 py-2 text-xs text-destructive-foreground ring-1 ring-destructive/40">
          {error}
        </p>
      )}

      {/* ETAPA 1 — calculando rota */}
      {(!route || busy) && uiStage === "route_preview" && (
        <div className="flex items-center justify-center gap-3 rounded-2xl bg-background/60 px-4 py-6 ring-1 ring-border">
          <span className="h-5 w-5 animate-spin rounded-full border-2 border-primary border-t-transparent" />
          <span className="text-sm font-medium text-muted-foreground">
            Calculando rota...
          </span>
        </div>
      )}

      {/* ETAPA 2 — resumo em uma linha + Continuar */}
      {uiStage === "route_preview" && route && !busy && (
        <div className="animate-in fade-in slide-in-from-bottom-2 duration-200">
          <FareEstimateCard route={route} fare={previewFare} />
          <button
            type="button"
            onClick={() => {
              console.log("[MOVVI UI] botão continuar clicado");
              setUiStage("selecting_category");
              onExpandSheet(70);
            }}
            className="w-full rounded-2xl bg-primary py-3.5 text-[14px] font-bold text-primary-foreground shadow-xl shadow-primary/25 transition active:scale-[0.98]"
          >
            Continuar
          </button>
        </div>
      )}

      {/* ETAPA 3 — carrossel horizontal de categorias */}
      {uiStage === "selecting_category" && route && (
        <RideCategorySelector
          route={route}
          km={km}
          min={min}
          tariffs={tariffs}
          selectedCategoryKey={selectedCategoryKey}
          onSelect={(c) => {
            console.log("[MOVVI UI] categoria selecionada:", c.label);
            setSelectedCategoryKey(c.key);
            setUiStage("confirming_request");
          }}
        />
      )}

      {/* ETAPA 4 — confirmação + botão inline */}
      {uiStage === "confirming_request" && route && selectedCategory && selectedFare != null && (
        <div className="animate-in fade-in slide-in-from-bottom-2 duration-200 space-y-2">
          <div className="flex items-center gap-2.5 rounded-2xl bg-primary/5 px-3 py-2.5 ring-1 ring-primary/30">
            <span className="grid h-10 w-10 shrink-0 place-items-center rounded-xl bg-primary text-primary-foreground">
              <selectedCategory.icon className="h-5 w-5" />
            </span>
            <div className="min-w-0 flex-1">
              <div className="text-[9.5px] font-semibold uppercase tracking-widest text-primary leading-none">
                Categoria
              </div>
              <div className="mt-0.5 truncate text-[14px] font-extrabold text-foreground leading-tight">
                {selectedCategory.label}
              </div>
            </div>
            <div className="text-right">
              <div className="text-[9.5px] font-semibold uppercase tracking-widest text-muted-foreground leading-none">
                Estimado
              </div>
              <div className="mt-0.5 text-[16px] font-extrabold text-foreground leading-none">
                {formatBRL(selectedFare)}
              </div>
            </div>
          </div>

          <button
            type="button"
            className="flex w-full items-center gap-2.5 rounded-2xl bg-background/60 px-3 py-2.5 text-left ring-1 ring-border transition hover:bg-accent/20"
          >
            <span className="grid h-8 w-8 shrink-0 place-items-center rounded-xl bg-primary/10 text-primary">
              <CreditCard className="h-4 w-4" />
            </span>
            <div className="min-w-0 flex-1">
              <div className="text-[9.5px] font-semibold uppercase tracking-widest text-muted-foreground leading-none">
                Forma de pagamento
              </div>
              <div className="mt-0.5 truncate text-[13px] font-bold text-foreground leading-tight">
                Dinheiro
              </div>
            </div>
            <ChevronRight className="h-4 w-4 shrink-0 text-muted-foreground" />
          </button>

          <RequestRideButton busy={busy} categoryLabel={selectedCategory.label} onSubmit={onSubmit} />
        </div>
      )}
    </div>
  );
}

function FareEstimateCard({ route, fare }: { route: RouteResult; fare: number | null }) {
  return (
    <div className="mb-3 rounded-2xl bg-primary/5 px-4 py-4 ring-1 ring-primary/30">
      <div className="flex flex-wrap items-baseline justify-center gap-x-2 gap-y-1 text-center">
        <span className="text-[15px] font-extrabold text-foreground">
          {fmtMin(route.durationSeconds)}
        </span>
        <span className="text-muted-foreground">•</span>
        <span className="text-[15px] font-extrabold text-foreground">
          {fmtKm(route.distanceMeters)}
        </span>
        <span className="text-muted-foreground">•</span>
        <span className="text-[15px] font-extrabold text-primary">
          {fare != null ? formatBRL(fare) : "Valor estimado"}
        </span>
      </div>
      <p className="mt-1.5 text-center text-[10.5px] text-muted-foreground">
        Valor estimado. Pode variar conforme rota e disponibilidade.
      </p>
    </div>
  );
}

function RideCategorySelector({
  route,
  km,
  min,
  tariffs,
  selectedCategoryKey,
  onSelect,
}: {
  route: RouteResult;
  km: number;
  min: number;
  tariffs: TariffMap;
  selectedCategoryKey: string | null;
  onSelect: (category: UiCategory) => void;
}) {
  return (
    <div className="animate-in fade-in slide-in-from-bottom-2 duration-200">
      <div className="mb-2 text-[11px] font-semibold uppercase tracking-widest text-muted-foreground">
        Escolha a categoria
      </div>
      <div className="-mx-4 mb-3 overflow-x-auto px-4 [scrollbar-width:none] [&::-webkit-scrollbar]:hidden">
        <div className="flex snap-x snap-mandatory gap-2.5 pb-1">
          {UI_CATEGORIES.map((c) => {
            const active = c.key === selectedCategoryKey;
            const fare = estimateFare(c.backend, km, min, tariffs);
            const Icon = c.icon;
            return (
              <button
                key={c.key}
                type="button"
                onClick={() => onSelect(c)}
                aria-pressed={active}
                className={`flex w-[120px] shrink-0 snap-start flex-col items-center gap-1.5 rounded-2xl border-2 px-3 py-3 text-center transition active:scale-95 ${
                  active
                    ? "border-primary bg-primary/10 shadow-md shadow-primary/20"
                    : "border-border bg-background/60 hover:border-primary/40"
                }`}
              >
                <span
                  className={`grid h-10 w-10 place-items-center rounded-xl ${
                    active ? "bg-primary text-primary-foreground" : "bg-primary/10 text-primary"
                  }`}
                >
                  <Icon className="h-5 w-5" />
                </span>
                <span className="text-[12.5px] font-bold leading-none">{c.label}</span>
                <span className="text-[10px] leading-none text-muted-foreground">
                  {fmtMin(route.durationSeconds)}
                </span>
                <span className="text-[12.5px] font-extrabold leading-none text-primary">
                  {formatBRL(fare)}
                </span>
              </button>
            );
          })}
        </div>
      </div>
    </div>
  );
}

function RequestRideButton({
  busy,
  categoryLabel,
  onSubmit,
}: {
  busy: boolean;
  categoryLabel: string;
  onSubmit: () => void;
}) {
  return (
    <button
      type="button"
      disabled={busy}
      onClick={onSubmit}
      className="mt-1 w-full rounded-2xl bg-primary py-3.5 text-[15px] font-extrabold text-primary-foreground shadow-xl shadow-primary/30 transition active:scale-[0.98] disabled:cursor-not-allowed disabled:opacity-50"
    >
      {busy ? "Solicitando..." : `Solicitar MOVVI ${categoryLabel}`}
    </button>
  );
}

function EnviosBlock({
  mode,
  setMode,
  size,
  setSize,
  fare,
}: {
  mode: "enviar" | "receber";
  setMode: (m: "enviar" | "receber") => void;
  size: "P" | "M" | "G";
  setSize: (s: "P" | "M" | "G") => void;
  fare: number | null;
}) {
  return (
    <div className="mb-2.5 space-y-2.5">
      <div className="flex gap-2">
        <button
          type="button"
          onClick={() => setMode("enviar")}
          className={`flex-1 rounded-xl border-2 px-3 py-2.5 text-left transition ${
            mode === "enviar"
              ? "border-primary bg-primary/10"
              : "border-border bg-background/60"
          }`}
        >
          <div className="flex items-center gap-2">
            <Send className="h-4 w-4 text-primary" />
            <span className="text-[12.5px] font-bold">Enviar pacote</span>
          </div>
          <p className="mt-0.5 text-[10.5px] text-muted-foreground">
            Você despacha no endereço atual
          </p>
        </button>
        <button
          type="button"
          onClick={() => setMode("receber")}
          className={`flex-1 rounded-xl border-2 px-3 py-2.5 text-left transition ${
            mode === "receber"
              ? "border-primary bg-primary/10"
              : "border-border bg-background/60"
          }`}
        >
          <div className="flex items-center gap-2">
            <Package className="h-4 w-4 text-primary" />
            <span className="text-[12.5px] font-bold">Receber pacote</span>
          </div>
          <p className="mt-0.5 text-[10.5px] text-muted-foreground">
            Coleta na origem indicada
          </p>
        </button>
      </div>

      <div>
        <div className="mb-1 px-1 text-[10px] font-semibold uppercase tracking-wider text-muted-foreground">
          Tamanho do pacote
        </div>
        <div className="flex gap-2">
          {(["P", "M", "G"] as const).map((s) => (
            <button
              key={s}
              type="button"
              onClick={() => setSize(s)}
              className={`flex-1 rounded-xl border-2 py-2 text-[12px] font-bold transition ${
                size === s
                  ? "border-primary bg-primary/10 text-primary"
                  : "border-border bg-background/60 text-muted-foreground"
              }`}
            >
              {s === "P" ? "Pequeno" : s === "M" ? "Médio" : "Grande"}
            </button>
          ))}
        </div>
      </div>

      {fare != null && (
        <div className="flex items-center justify-between rounded-xl bg-background/60 px-3 py-2 ring-1 ring-border">
          <span className="text-[11px] uppercase tracking-wide text-muted-foreground">
            Valor estimado
          </span>
          <span className="text-base font-bold text-primary">{formatBRL(fare)}</span>
        </div>
      )}
    </div>
  );
}



/* ============================================================ */
/*                         SUB COMPONENTS                       */
/* ============================================================ */


function Stat({
  icon,
  label,
  value,
  highlight,
}: {
  icon: React.ReactNode;
  label: string;
  value: string;
  highlight?: boolean;
}) {
  return (
    <div className="rounded-xl bg-background/60 px-3 py-2 ring-1 ring-border">
      <div className="flex items-center gap-1 text-[10px] uppercase tracking-wide text-muted-foreground">
        {icon}
        {label}
      </div>
      <div
        className={`text-base font-bold ${
          highlight ? "text-primary" : "text-foreground"
        }`}
      >
        {value}
      </div>
    </div>
  );
}

function SearchingPanel({
  category,
  driversCount,
  onCancel,
}: {
  category: RideCategory;
  driversCount: number;
  onCancel: () => void;
}) {
  const cat = RIDE_CATEGORIES.find((c) => c.key === category)!;
  const [elapsed, setElapsed] = useState(0);
  useEffect(() => {
    const i = setInterval(() => setElapsed((s) => s + 1), 1000);
    return () => clearInterval(i);
  }, []);
  // raio em km cresce com o tempo (cap 8km), animado
  const radiusKm = Math.min(8, 1 + elapsed * 0.25);
  const mm = Math.floor(elapsed / 60)
    .toString()
    .padStart(2, "0");
  const ss = (elapsed % 60).toString().padStart(2, "0");

  return (
    <div className="px-1 pt-1 text-center">
      {/* Pulso multi-anel */}
      <div className="relative mx-auto mb-3 grid h-28 w-28 place-items-center">
        <span className="absolute inset-0 animate-ping rounded-full bg-primary/20 [animation-duration:1.8s]" />
        <span className="absolute inset-3 animate-ping rounded-full bg-primary/30 [animation-duration:1.4s]" />
        <span className="absolute inset-6 animate-ping rounded-full bg-primary/40 [animation-duration:1s]" />
        <span className="relative grid h-16 w-16 place-items-center rounded-full bg-primary text-3xl shadow-2xl shadow-primary/40">
          {cat.emoji}
        </span>
      </div>

      <h2 className="font-display text-[17px] font-extrabold leading-tight">
        Procurando motoristas...
      </h2>
      <p className="mt-0.5 text-[11.5px] text-muted-foreground">
        Conectando com {cat.label} próximos a você
      </p>

      {/* Métricas em tempo real */}
      <div className="mt-3 grid grid-cols-3 gap-1.5">
        <div className="rounded-xl bg-primary/10 px-1.5 py-2 ring-1 ring-primary/30">
          <div className="text-[16px] font-extrabold tabular-nums leading-none text-primary">
            {driversCount}
          </div>
          <div className="mt-0.5 text-[9.5px] uppercase tracking-wider text-muted-foreground">
            Motoristas
          </div>
        </div>
        <div className="rounded-xl bg-background/60 px-1.5 py-2 ring-1 ring-border">
          <div className="text-[16px] font-extrabold tabular-nums leading-none text-foreground">
            {radiusKm.toFixed(1)}<span className="text-[10px] font-bold">km</span>
          </div>
          <div className="mt-0.5 text-[9.5px] uppercase tracking-wider text-muted-foreground">
            Raio
          </div>
        </div>
        <div className="rounded-xl bg-background/60 px-1.5 py-2 ring-1 ring-border">
          <div className="text-[16px] font-extrabold tabular-nums leading-none text-foreground">
            {mm}:{ss}
          </div>
          <div className="mt-0.5 text-[9.5px] uppercase tracking-wider text-muted-foreground">
            Tempo
          </div>
        </div>
      </div>

      {/* Barra de progresso do raio */}
      <div className="mt-3 h-1.5 w-full overflow-hidden rounded-full bg-background/80 ring-1 ring-border">
        <div
          className="h-full rounded-full bg-gradient-to-r from-primary via-primary to-primary/60 transition-[width] duration-700 ease-out"
          style={{ width: `${(radiusKm / 8) * 100}%` }}
        />
      </div>
      <p className="mt-1.5 text-[10.5px] text-muted-foreground">
        Expandindo busca em tempo real...
      </p>

      <button
        onClick={onCancel}
        className="mt-3 w-full rounded-2xl border border-destructive/40 bg-destructive/10 py-2.5 text-[13px] font-semibold text-destructive-foreground transition active:scale-[0.98] hover:bg-destructive/20"
      >
        Cancelar solicitação
      </button>
    </div>
  );
}

function DriverEnRoute({
  ride,
  driver,
  onCancel,
}: {
  ride: RideRow;
  driver: DriverRow;
  onCancel: () => void;
}) {
  const phaseLabel =
    ride.status === "motorista_chegou"
      ? "Seu motorista chegou"
      : ride.status === "em_viagem"
        ? "Em viagem para o destino"
        : "Motorista a caminho";
  // ETA animado para fase "motorista a caminho"
  const isArriving = ride.status === "motorista_a_caminho" || ride.status === "procurar_motorista";
  const isInTrip = ride.status === "em_viagem";
  const [eta, setEta] = useState(() => Math.floor(Math.random() * 4) + 3);
  useEffect(() => {
    if (!isArriving) return;
    const i = setInterval(() => setEta((e) => (e > 1 ? e - 1 : 1)), 30000);
    return () => clearInterval(i);
  }, [isArriving]);

  return (
    <div className="pt-1 animate-in fade-in slide-in-from-bottom-2 duration-300">
      <div className="mb-2 flex items-center justify-center gap-2 text-[10.5px] font-bold uppercase tracking-widest text-primary">
        <span className="relative flex h-2 w-2">
          <span className="absolute inset-0 animate-ping rounded-full bg-primary/70" />
          <span className="relative h-2 w-2 rounded-full bg-primary" />
        </span>
        {phaseLabel}
      </div>

      {/* ETA destacado */}
      {!isInTrip && (
        <div className="mb-2 flex items-center justify-between gap-3 rounded-2xl bg-primary/10 px-3 py-2.5 ring-1 ring-primary/30">
          <div>
            <div className="text-[9.5px] font-semibold uppercase tracking-widest text-primary leading-none">
              Chegando em
            </div>
            <div className="mt-0.5 text-[22px] font-extrabold leading-none text-foreground tabular-nums">
              {eta} <span className="text-[12px] font-bold">min</span>
            </div>
          </div>
          <div className="text-right">
            <div className="text-[9.5px] font-semibold uppercase tracking-widest text-muted-foreground leading-none">
              Distância
            </div>
            <div className="mt-0.5 text-[15px] font-extrabold leading-none text-foreground tabular-nums">
              {(eta * 0.45).toFixed(1)} <span className="text-[10px] font-bold">km</span>
            </div>
          </div>
        </div>
      )}

      <div className="flex items-center gap-2.5 rounded-2xl bg-background/60 p-2.5 ring-1 ring-border">
        <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-full bg-primary/15 text-2xl">
          {driver.selfie_url ? (
            <img
              src={driver.selfie_url}
              alt={driver.name}
              className="h-12 w-12 rounded-full object-cover"
            />
          ) : (
            "👤"
          )}
        </div>
        <div className="min-w-0 flex-1">
          <div className="flex items-center gap-1.5">
            <span className="truncate text-[13.5px] font-bold">{driver.name}</span>
            <span className="inline-flex shrink-0 items-center gap-0.5 text-[11px] text-yellow-400">
              <Star className="h-3 w-3 fill-current" />
              {driver.rating?.toFixed(1) ?? "5.0"}
            </span>
          </div>
          <div className="truncate text-[11.5px] text-muted-foreground">
            {driver.vehicle_color} · {driver.vehicle_model}
          </div>
          <div className="mt-0.5 inline-flex items-center rounded bg-white px-1.5 py-0.5 text-[10px] font-extrabold tracking-widest text-black">
            {driver.vehicle_plate}
          </div>
        </div>
      </div>

      <div className="mt-2 grid grid-cols-4 gap-1.5 text-xs">
        <Action icon={<Phone className="h-4 w-4" />} label="Ligar" />
        <Action icon={<Navigation2 className="h-4 w-4" />} label="Compartilhar" />
        <Action
          icon={<Shield className="h-4 w-4" />}
          label="SOS"
          tone="destructive"
        />
        <button
          onClick={onCancel}
          className="flex flex-col items-center gap-1 rounded-xl bg-background/60 py-2.5 ring-1 ring-border transition active:scale-95 hover:ring-destructive/50"
        >
          <X className="h-4 w-4" />
          <span className="text-[10.5px]">Cancelar</span>
        </button>
      </div>

      <div className="mt-2 rounded-xl bg-background/60 px-3 py-2 text-[11.5px] ring-1 ring-border">
        <div className="flex items-center gap-1.5">
          <MapPin className="h-3 w-3 shrink-0 text-destructive" />
          <span className="truncate">{ride.destination_name}</span>
        </div>
        {ride.estimated_price && (
          <div className="mt-0.5 flex items-center justify-between text-muted-foreground">
            <span>Estimativa</span>
            <span className="font-bold text-primary">
              {formatBRL(Number(ride.estimated_price))}
            </span>
          </div>
        )}
      </div>
    </div>
  );
}

function Action({
  icon,
  label,
  tone,
}: {
  icon: React.ReactNode;
  label: string;
  tone?: "destructive";
}) {
  return (
    <button
      className={`flex flex-col items-center gap-1 rounded-xl py-3 ring-1 ring-border ${
        tone === "destructive"
          ? "bg-destructive/10 text-destructive-foreground hover:bg-destructive/20"
          : "bg-background/60 hover:ring-primary/40"
      }`}
    >
      {icon}
      <span className="text-[11px]">{label}</span>
    </button>
  );
}

function GpsDeniedScreen({
  mode = "denied",
  onRetry,
  onHome,
  onManual,
  errorMessage,
  requesting,
}: {
  mode?: "prompt" | "denied";
  onRetry: () => void;
  onHome: () => void;
  onManual: (p: LatLng) => void;
  errorMessage: string;
  requesting: boolean;
}) {
  const isPrompt = mode === "prompt";
  const title = isPrompt
    ? "Ative sua localização"
    : "Não foi possível obter sua localização";
  const description = isPrompt
    ? "A MOVVI precisa da sua localização para encontrar motoristas próximos e calcular sua corrida."
    : errorMessage ||
      "Não conseguimos acessar sua localização automaticamente. Digite sua origem manualmente.";
  const primaryLabel = requesting
    ? "Solicitando..."
    : isPrompt
    ? "Permitir acesso à minha localização"
    : "Tentar novamente";
  const [manualOpen, setManualOpen] = useState(!isPrompt);
  const [query, setQuery] = useState("");
  const [items, setItems] = useState<{ placeId: string; primary: string; secondary: string }[]>([]);
  const [searching, setSearching] = useState(false);
  const [manualError, setManualError] = useState("");
  const debounceRef = useRef<number | null>(null);
  const { isLoaded: mapsReady, loadError: mapsLoadError } = useJsApiLoader({
    id: "movvi-google-maps",
    googleMapsApiKey: GOOGLE_MAPS_API_KEY,
    libraries: GOOGLE_MAPS_LIBRARIES,
    language: "pt-BR",
    region: "BR",
  });

  useEffect(() => {
    if (errorMessage) setManualOpen(true);
  }, [errorMessage]);

  useEffect(() => {
    if (debounceRef.current) window.clearTimeout(debounceRef.current);
    const q = query.trim();
    setManualError("");
    if (q.length < 2) {
      setItems([]);
      return;
    }
    if (!mapsReady) return;
    debounceRef.current = window.setTimeout(async () => {
      try {
        setSearching(true);
        const { AutocompleteSuggestion, AutocompleteSessionToken } =
          (await google.maps.importLibrary("places")) as google.maps.PlacesLibrary;
        const sessionToken = new AutocompleteSessionToken();
        const { suggestions } = await AutocompleteSuggestion.fetchAutocompleteSuggestions({
          input: q,
          sessionToken,
          includedRegionCodes: ["br"],
          language: "pt-BR",
          region: "BR",
        });
        setItems(
          suggestions
            .map((s) => s.placePrediction)
            .filter(Boolean)
            .map((p) => ({
              placeId: p!.placeId,
              primary: p!.mainText?.text ?? p!.text?.text ?? "",
              secondary: p!.secondaryText?.text ?? "",
            }))
            .slice(0, 6),
        );
      } catch (e) {
        console.error("Erro no autocomplete manual:", e);
        setManualError("Falha temporária na busca de endereços. Tente novamente em alguns segundos.");
      } finally {
        setSearching(false);
      }
    }, 250);
  }, [query, mapsReady]);

  async function choose(placeId: string, label: string) {
    try {
      setManualError("");
      const { Place } = (await google.maps.importLibrary("places")) as google.maps.PlacesLibrary;
      const place = new Place({ id: placeId });
      await place.fetchFields({ fields: ["location"] });
      const loc = place.location;
      if (!loc) throw new Error("Sem coordenadas");
      const point = { lat: loc.lat(), lng: loc.lng() };
      console.log("Manual selecionado:", label, point.lat, point.lng);
      if (!isBrazilCoordinate(point.lat, point.lng)) {
        setManualError("Escolha uma cidade ou endereço dentro do Brasil.");
        return;
      }
      onManual(point);
    } catch (e) {
      console.error("Erro ao obter coordenadas do lugar:", e);
      setManualError("Não foi possível obter as coordenadas desse endereço.");
    }
  }

  async function submitManualSearch() {
    const first = items[0];
    if (first) {
      await choose(first.placeId, `${first.primary} ${first.secondary}`);
      return;
    }
    if (!mapsReady || query.trim().length < 2) return;
    setManualError("Digite um endereço no Brasil e selecione uma opção da lista.");
  }

  const showDevBadge = DEV_MODE && isDevelopmentEnvironment();

  return (
    <div className="relative flex min-h-[100dvh] flex-col items-center justify-center bg-background px-6 text-center text-foreground">
      <div className="absolute left-4 top-4 flex items-center gap-2">
        <button
          onClick={onHome}
          className="inline-flex items-center gap-2 rounded-full bg-card px-3 py-2 text-xs font-medium ring-1 ring-border"
        >
          ← Início
        </button>
        {showDevBadge && (
          <a
            href="/dev-diagnostics"
            className="inline-flex items-center gap-1 rounded-full bg-amber-500/15 px-3 py-2 text-[11px] font-bold uppercase tracking-wider text-amber-400 ring-1 ring-amber-500/40"
            title="Ambiente de desenvolvimento — abrir diagnóstico"
          >
            🧪 Diagnóstico
          </a>
        )}
      </div>
      <div className="mx-auto mb-6 flex h-20 w-20 items-center justify-center rounded-3xl bg-primary/15 text-primary">
        <MapPin className="h-9 w-9" />
      </div>
      <h1 className="font-display text-2xl font-bold">{title}</h1>
      <p className="mt-2 max-w-sm text-sm text-muted-foreground">{description}</p>
      {showDevBadge && (
        <p className="mt-3 max-w-sm rounded-xl bg-amber-500/10 px-3 py-2 text-[12px] text-amber-300 ring-1 ring-amber-500/30">
          Ambiente de teste detectado. A localização real pode não funcionar corretamente aqui — use a busca manual abaixo.
        </p>
      )}
      {mapsLoadError && (
        <p className="mt-3 max-w-sm rounded-xl bg-destructive/10 px-3 py-2 text-[12px] text-destructive ring-1 ring-destructive/30">
          Falha temporária ao carregar o mapa. Verifique sua conexão e toque em tentar novamente.
        </p>
      )}


      <div className="mt-6 flex w-full max-w-sm flex-col gap-3">
        <button
          type="button"
          onClick={() => {
            console.log("[MOVVI] Clique em", primaryLabel);
            onRetry();
          }}
          disabled={requesting}
          className="inline-flex items-center justify-center gap-2 rounded-2xl bg-primary px-6 py-4 text-sm font-bold text-primary-foreground shadow-xl shadow-primary/30 active:scale-95 disabled:opacity-60"
        >
          <Crosshair className="h-4 w-4" />
          {primaryLabel}
        </button>

        <button
          type="button"
          onClick={() => setManualOpen((v) => !v)}
          className="inline-flex items-center justify-center gap-2 rounded-2xl bg-card px-6 py-4 text-sm font-semibold text-foreground ring-1 ring-border active:scale-95"
        >
          <Search className="h-4 w-4" /> Digitar origem manualmente
        </button>
      </div>



      {manualOpen && (
        <div className="mt-4 w-full max-w-sm rounded-2xl bg-card p-4 ring-1 ring-border text-left">
          <label className="text-xs font-medium text-muted-foreground">
            Digite cidade ou endereço
          </label>
          <input
            autoFocus
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === "Enter") void submitManualSearch();
            }}
            placeholder="Digite seu endereço, bairro ou cidade"
            className="mt-2 w-full rounded-xl bg-background px-3 py-3 text-sm outline-none ring-1 ring-border focus:ring-primary"
          />
          {mapsLoadError && (
            <p className="mt-2 text-xs text-destructive">Falha ao carregar a busca do Google Maps.</p>
          )}
          {!mapsReady && !mapsLoadError && (
            <p className="mt-2 text-xs text-muted-foreground">Carregando busca...</p>
          )}
          {searching && (
            <p className="mt-2 text-xs text-muted-foreground">Buscando...</p>
          )}
          <ul className="mt-2 max-h-64 overflow-y-auto">
            {items.map((it) => (
              <li key={it.placeId}>
                <button
                  type="button"
                  onClick={() => choose(it.placeId, `${it.primary} ${it.secondary}`)}
                  className="flex w-full flex-col items-start gap-0.5 rounded-lg px-2 py-2 text-left hover:bg-background"
                >
                  <span className="text-sm font-medium">{it.primary}</span>
                  <span className="text-xs text-muted-foreground">{it.secondary}</span>
                </button>
              </li>
            ))}
          </ul>
          {query.trim().length >= 2 && !searching && mapsReady && items.length === 0 && (
            <p className="mt-2 text-xs text-muted-foreground">
              Continue digitando seu endereço e selecione uma sugestão da lista.
            </p>
          )}
          {manualError && <p className="mt-3 text-xs text-destructive">{manualError}</p>}
          <button
            type="button"
            onClick={() => void submitManualSearch()}
            disabled={!mapsReady || searching || query.trim().length < 2}
            className="mt-3 w-full rounded-xl bg-primary px-4 py-3 text-sm font-bold text-primary-foreground disabled:opacity-50"
          >
            CONFIRMAR LOCALIZAÇÃO
          </button>
        </div>
      )}
    </div>
  );
}

function OriginMapPickerOverlay({
  mapRef,
  initialCenter,
  onCancel,
  onConfirm,
}: {
  mapRef: React.MutableRefObject<google.maps.Map | null>;
  initialCenter: LatLng;
  onCancel: () => void;
  onConfirm: (p: LatLng) => void;
}) {
  const [center, setCenter] = useState<LatLng>(initialCenter);
  const [valid, setValid] = useState<boolean>(isBrazilCoordinate(initialCenter.lat, initialCenter.lng));

  useEffect(() => {
    const map = mapRef.current;
    if (!map) return;
    const update = () => {
      const c = map.getCenter();
      if (!c) return;
      const p = { lat: c.lat(), lng: c.lng() };
      setCenter(p);
      setValid(isBrazilCoordinate(p.lat, p.lng));
    };
    update();
    const l1 = map.addListener("center_changed", update);
    return () => {
      l1.remove();
    };
  }, [mapRef]);

  return (
    <>
      {/* Crosshair fixo no centro */}
      <div className="pointer-events-none absolute inset-0 z-[55] flex items-center justify-center">
        <div className="relative -translate-y-2">
          <div className="h-10 w-10 rounded-full bg-primary/20 ring-2 ring-primary/60" />
          <div className="absolute left-1/2 top-1/2 h-3 w-3 -translate-x-1/2 -translate-y-1/2 rounded-full bg-primary ring-2 ring-white" />
          <div className="absolute left-1/2 top-full h-4 w-0.5 -translate-x-1/2 bg-primary/70" />
        </div>
      </div>

      {/* Barra superior com instrução */}
      <div className="absolute inset-x-0 top-0 z-[56] flex justify-center px-3 pt-[calc(env(safe-area-inset-top)+10px)]">
        <div className="flex max-w-md items-center gap-2 rounded-2xl bg-card/95 px-3 py-2 text-[12.5px] font-medium shadow-xl ring-1 ring-border backdrop-blur">
          <MapPin className="h-4 w-4 text-primary" />
          Arraste o mapa e ajuste o ponto de partida
        </div>
      </div>

      {/* Card inferior com confirmação */}
      <div className="absolute inset-x-0 bottom-0 z-[56] px-3 pb-[calc(env(safe-area-inset-bottom)+16px)]">
        <div className="mx-auto max-w-md rounded-2xl bg-card p-4 shadow-2xl ring-1 ring-border">
          <div className="text-[10px] font-semibold uppercase tracking-widest text-primary">
            Novo local de partida
          </div>
          <div className="mt-1 font-mono text-[12px] text-foreground/80">
            {center.lat.toFixed(6)}, {center.lng.toFixed(6)}
          </div>
          {!valid && (
            <p className="mt-2 rounded-xl bg-destructive/15 px-2 py-1.5 text-[11.5px] text-destructive-foreground ring-1 ring-destructive/40">
              Selecione um ponto dentro do Brasil.
            </p>
          )}
          <div className="mt-3 flex gap-2">
            <button
              type="button"
              onClick={onCancel}
              className="flex-1 rounded-xl bg-background/60 py-3 text-[13px] font-semibold ring-1 ring-border active:scale-[0.98]"
            >
              Cancelar
            </button>
            <button
              type="button"
              onClick={() => onConfirm(center)}
              disabled={!valid}
              className="flex-1 rounded-xl bg-primary py-3 text-[13px] font-bold text-primary-foreground shadow-md shadow-primary/20 active:scale-[0.98] disabled:opacity-50"
            >
              Confirmar partida
            </button>
          </div>
        </div>
      </div>
    </>
  );
}

function OriginManualSearchOverlay({
  onCancel,
  onConfirm,
}: {
  onCancel: () => void;
  onConfirm: (p: LatLng) => void;
}) {
  const [query, setQuery] = useState("");
  const [items, setItems] = useState<{ placeId: string; primary: string; secondary: string }[]>([]);
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState("");
  const debounceRef = useRef<number | null>(null);
  const sessionRef = useRef<google.maps.places.AutocompleteSessionToken | null>(null);

  useEffect(() => {
    if (debounceRef.current) window.clearTimeout(debounceRef.current);
    const q = query.trim();
    setErr("");
    if (q.length < 2) {
      setItems([]);
      return;
    }
    debounceRef.current = window.setTimeout(async () => {
      try {
        setBusy(true);
        const places = (await google.maps.importLibrary("places")) as google.maps.PlacesLibrary;
        if (!sessionRef.current) sessionRef.current = new places.AutocompleteSessionToken();
        const { suggestions } = await places.AutocompleteSuggestion.fetchAutocompleteSuggestions({
          input: q,
          sessionToken: sessionRef.current,
          includedRegionCodes: ["br"],
          language: "pt-BR",
          region: "BR",
        });
        setItems(
          suggestions
            .map((s) => s.placePrediction)
            .filter((p): p is google.maps.places.PlacePrediction => !!p)
            .slice(0, 6)
            .map((p) => ({
              placeId: p.placeId,
              primary: p.mainText?.toString() ?? p.text.toString(),
              secondary: p.secondaryText?.toString() ?? "",
            })),
        );
      } catch (e) {
        console.error("[MOVVI] autocomplete origem manual", e);
        setErr("Falha na busca. Tente novamente em alguns segundos.");
      } finally {
        setBusy(false);
      }
    }, 220);
  }, [query]);

  async function choose(placeId: string) {
    try {
      setErr("");
      const places = (await google.maps.importLibrary("places")) as google.maps.PlacesLibrary;
      const place = new places.Place({ id: placeId });
      await place.fetchFields({ fields: ["location"] });
      const loc = place.location;
      if (!loc) throw new Error("Sem coordenadas");
      const p = { lat: loc.lat(), lng: loc.lng() };
      if (!isBrazilCoordinate(p.lat, p.lng)) {
        setErr("Selecione um endereço dentro do Brasil.");
        return;
      }
      sessionRef.current = null;
      onConfirm(p);
    } catch (e) {
      console.error("[MOVVI] falha origem manual", e);
      setErr("Não foi possível obter as coordenadas desse endereço.");
    }
  }

  return (
    <div className="fixed inset-0 z-[60] flex flex-col bg-background text-foreground">
      <div className="flex items-center gap-2 border-b border-border bg-card px-4 py-3 pt-[calc(env(safe-area-inset-top)+12px)]">
        <button
          type="button"
          onClick={onCancel}
          aria-label="Voltar"
          className="grid h-9 w-9 place-items-center rounded-full bg-background/60 ring-1 ring-border active:scale-90"
        >
          <X className="h-4 w-4" />
        </button>
        <div className="flex flex-1 items-center gap-2 rounded-xl bg-background/70 px-3 py-2 ring-1 ring-border focus-within:ring-primary/60">
          <Search className="h-4 w-4 text-primary" />
          <input
            autoFocus
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Digite rua, bairro, cidade ou CEP"
            className="min-w-0 flex-1 bg-transparent text-[14px] outline-none placeholder:text-muted-foreground"
          />
          {busy && <span className="text-[11px] text-muted-foreground">...</span>}
        </div>
      </div>

      <div className="flex-1 overflow-y-auto px-2 py-2">
        {err && (
          <p className="mx-2 my-2 rounded-xl bg-destructive/10 px-3 py-2 text-[12px] text-destructive-foreground ring-1 ring-destructive/40">
            {err}
          </p>
        )}
        {items.length === 0 && query.trim().length >= 2 && !busy && (
          <p className="px-3 py-6 text-center text-[12.5px] text-muted-foreground">
            Nenhum resultado. Tente outro termo.
          </p>
        )}
        <ul>
          {items.map((it) => (
            <li key={it.placeId}>
              <button
                type="button"
                onClick={() => void choose(it.placeId)}
                className="flex w-full items-start gap-3 rounded-xl px-3 py-3 text-left transition hover:bg-accent/30 active:scale-[0.99]"
              >
                <span className="mt-0.5 grid h-9 w-9 shrink-0 place-items-center rounded-full bg-primary/15 text-primary">
                  <MapPin className="h-4 w-4" />
                </span>
                <span className="flex min-w-0 flex-col">
                  <span className="truncate text-[13.5px] font-semibold">{it.primary}</span>
                  {it.secondary && (
                    <span className="truncate text-[11.5px] text-muted-foreground">{it.secondary}</span>
                  )}
                </span>
              </button>
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
}

function LogoMark() {
  return (
    <svg width={22} height={22} viewBox="0 0 120 120" aria-hidden>
      <path d="M18 100 L18 28 L40 28 L60 70 L60 100 Z" fill="white" />
      <path
        d="M60 28 Q100 28 100 64 Q100 100 60 100 L60 78 Q82 78 82 64 Q82 50 60 50 Z"
        fill="hsl(95 75% 51%)"
      />
    </svg>
  );
}
